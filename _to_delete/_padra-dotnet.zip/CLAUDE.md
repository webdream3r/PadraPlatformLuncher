# Padra Platform Launcher

Local model gateway and desktop control panel, on .NET 8. Runs a fleet of
`unsloth run` backends behind one OpenAI/Anthropic-compatible endpoint so OpenAI
Codex, Qwen Code, Claude Code and VS Code can select a model per request, from
this machine or from anywhere on the LAN.

## Stack

- .NET 8, C# 12, nullable enabled, warnings as errors
- `Padra.Core` — domain library, no ASP.NET dependency
- `Padra.Web` — ASP.NET Core gateway + Blazor Server panel (`Padra.Server.exe`)
- `Padra.Desktop` — WPF + WebView2 window (Windows only), supervises the gateway
- `Padra.Tests` — xunit, real HTTP against a stub backend

## Commands

```bash
dotnet build                                  # whole solution
dotnet test                                   # 110 tests
./run-server.sh --lan                         # headless gateway on the LAN
pwsh ./publish.ps1                            # dist\Padra Platform Launcher.exe (Windows)
dotnet run --project src/Padra.Web -- --help  # gateway options
```

`Padra.Desktop` targets `net8.0-windows`; it compiles anywhere with
`EnableWindowsTargeting` but only runs on Windows.

## Module map

| Namespace | Owns |
| --- | --- |
| `Padra.Core.Configuration` | `models.yaml` load/validate/mutate/atomic save, user settings, the starter config |
| `Padra.Core.Discovery` | local GGUF scan (Hugging Face cache, LM Studio), GGUF header parsing, Hugging Face catalog |
| `Padra.Core.Networking` | LAN addresses, endpoint URLs, port checks, firewall rule |
| `Padra.Core.Runtime` | `ModelBackend`, `ModelFleet`, `ActivityLog`, `OrphanRegistry` |
| `Padra.Core.Clients` | client configuration generation/install and agent launching |
| `Padra.Web.Endpoints` | `/v1`, `/admin`, `/api` |
| `Padra.Web.Components` | the Blazor panel |

## Conventions

- Every user-facing string is a key in **both** `UiStrings.resx` and
  `UiStrings.fa-IR.resx`, resolved with `IStringLocalizer<UiStrings>`. Never
  inline text in a component; `LocalizationTests` fails otherwise.
- CSS uses logical properties only (`margin-inline`, `inset-inline`,
  `text-align: start`). No `left` / `right`. The panel must render correctly with
  `dir="rtl"` and `dir="ltr"`.
- Numbers, sizes and dates go through `CultureFormat`, which supplies Persian
  digits and the Jalali calendar for `fa-IR`.
- The gateway owns backend processes. Anything that starts a process must also
  stop it on shutdown; `OrphanRegistry` cleans up after a crash, and the desktop
  shell calls `POST /api/shutdown` before it terminates anything.
- `models.yaml` uses camelCase keys and is rewritten atomically with its header
  comment intact; it stays hand-editable.
- Client configuration is always merged, never overwritten: keep unrelated keys,
  back up to `.bak`, and stay idempotent. Codex text goes inside the
  `# >>> padra-platform-launcher >>>` markers, and only as a `[table]` — bare
  TOML keys appended to a file would be swallowed by the preceding section.
- Verified client facts, not guesses: Codex uses `env_key` (not `OPENAI_*`) and
  separate profile files; `--oss` is Ollama/LM Studio only; Claude Code speaks
  the Anthropic Messages API at `ANTHROPIC_BASE_URL` with real SSE streaming, so
  the proxy must not buffer.
- A windowed build has no console. Everything diagnostic also goes to
  `padra-launcher.log` next to the executable.

<!-- BEGIN owner-global-rules -->
## Owner-mandated global rules (binding — every change, request, prompt, scheduled run)
Full text: docs/GLOBAL-RULES.md. In short: (1) ripple-review every dependent
caller/DI/migration/view/test and keep build+tests green; (2) complete code only, no
stubs/placeholders; (3) research existing patterns first, then the complete/optimal
solution; (4) best UI/UX on the design system; (5) honest reporting; (6) no
demo/mock/sample — all operational; (7) i18n + RTL/LTR, no hardcoded strings.
<!-- END owner-global-rules -->
