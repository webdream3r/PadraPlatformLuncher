# Padra Platform Launcher

One local endpoint in front of every Unsloth model on your machine, plus a
localized control panel. Codex, Qwen Code, Claude Code and VS Code all point at
the same URL and pick a model per request — from this computer or from anywhere
on your network.

```
Codex ────┐                             ┌─► unsloth run :8801  (qwen3-coder)
Qwen ─────┤                             │
Claude ───┼──► gateway :8900/v1 ────────┼─► unsloth run :8802  (gemma-4)
VS Code ──┤    (this or any LAN machine)│
other PCs ┘                             └─► unsloth run :8803  (qwen3.5-4b)
```

Built on .NET 8: an ASP.NET Core gateway with a Blazor Server control panel, and
a WPF + WebView2 window that hosts it.

## Run it

**Windows** — build once, then double-click `dist\Padra Platform Launcher.exe`:

```powershell
powershell -ExecutionPolicy Bypass -File .\publish.ps1
```

The publish is self-contained: the target machine needs no .NET runtime. The
window starts the gateway, shows the panel, and on close asks the gateway to
unload every model so no VRAM is left occupied.

**Headless** (Windows, Linux, macOS):

```bash
./run-server.sh              # this computer only
./run-server.sh --lan        # serve the whole local network
```

or, from a publish folder, `Padra.Server --config models.yaml [--lan]`.

On the first run the launcher generates a strong API key into `models.yaml` and
imports the GGUF models it finds already downloaded on this machine.

## Prerequisites

```powershell
winget install --id Microsoft.DotNet.SDK.8            # to build
irm https://unsloth.ai/install.ps1 | iex              # Unsloth CLI
winget install --id OpenAI.Codex                      # Codex CLI      (optional)
npm install -g @qwen-code/qwen-code                   # Qwen Code CLI  (optional)
npm install -g @anthropic-ai/claude-code              # Claude Code    (optional)
```

macOS and Linux install Unsloth with `curl -fsSL https://unsloth.ai/install.sh | sh`.
The window also needs the WebView2 runtime, which ships with Windows 11 and
current Windows 10; without it the app offers to open the panel in your browser.

## Control panel

| Panel | What it does |
| --- | --- |
| **Models in the gateway** | Radio button picks the active model — it becomes the default and is loaded while the others are freed. Per-row Load / Unload / Remove, live state (idle, loaded, attached, failed). |
| **Model library → Downloaded** | Every GGUF already on this disk, with its real size, quantisation, context length read from the GGUF header, and where it came from. One click adds it to the gateway. |
| **Model library → Unsloth catalog** | Live search of the Unsloth organisation on Hugging Face: repositories, every quantisation variant, download size and context length, with the ones you already have marked. |
| **Coding agents** | Choose which agents to configure and whether to write the local or LAN address, install the configuration, download a zip for another machine, or open a project folder in Codex / Qwen Code / Claude Code with the endpoint, key and model already set. |
| **Network** | Share on the LAN, change the port, set an idle timeout that frees VRAM automatically, see every URL other machines can use, and add the Windows firewall rule. |
| **Activity log** | Live gateway output. |

Language switch: English and فارسی, full RTL, Persian digits and Jalali dates.
Strings live in `src/Padra.Web/UiStrings.resx` and `UiStrings.fa-IR.resx` and are
resolved with `IStringLocalizer`; the culture comes from a cookie through
`UseRequestLocalization`.

## Serving the whole network

Turn on **Share with the local network** (or run with `--lan`, or set
`gateway.host: 0.0.0.0`). The panel then lists every URL other machines can use
and the exact firewall command; on Windows the button adds the rule itself.

A shared gateway always requires the API key — remote callers with no key or the
wrong key get `401`. Loopback callers keep working without one. A browser cannot
send an `Authorization` header on a normal navigation, so to open the panel from
another machine append the key once: `http://<host>:8900/?key=<gateway key>`. It
is stored in a strict same-site cookie for that browser.

To set up another machine, click **Download config bundle** with the scope set to
*Local network address*. The zip contains ready-to-use files for every agent plus
`env.sh` / `env.ps1`, all pointing at this computer's LAN URL.

## Client configuration

The panel's **Install client configuration** button writes:

| Agent | File | What is written |
| --- | --- | --- |
| Codex CLI + `openai.chatgpt` VS Code extension | `~/.codex/config.toml` | a marker-delimited `[model_providers.unsloth_gw]` table with `base_url`, `env_key = UNSLOTH_GATEWAY_KEY`, `wire_api`, `requires_openai_auth = false` |
| Codex profiles | `~/.codex/<alias>.config.toml` | one file per model — `codex --profile <alias>` |
| Qwen Code | `~/.qwen/settings.json` | `modelProviders.openai[]`, `security.auth.selectedType`, `model.name`, `env` |
| Claude Code CLI + `anthropic.claude-code` | `~/.claude/settings.json` | `env.ANTHROPIC_BASE_URL`, `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_MODEL` and the haiku/sonnet/opus aliases |
| Claude Code in VS Code | VS Code `settings.json` | `claudeCode.environmentVariables`, `claudeCode.disableLoginPrompt` |
| Copilot Chat (bring your own key) | `chatLanguageModels.json` next to it | one `customendpoint` entry per model |
| Continue | `~/.continue/config.yaml` | one `provider: openai` model per alias |
| Workspace tasks | `generated/vscode/tasks.json` | start the gateway, check status, run each agent |

Everything is merged, not overwritten: unrelated keys survive, existing files are
copied to `.bak` first, and running it twice changes nothing.

Notes that cost time if you get them wrong:

- Codex reads the key from the environment variable named by `env_key`; it does
  **not** honour `OPENAI_BASE_URL` or `OPENAI_API_KEY`.
- `codex --oss` only selects Ollama or LM Studio. Use `--profile <alias>`.
- Codex profiles are separate files. `[profiles.x]` inside `config.toml` stopped
  working in Codex 0.134.0.
- Claude Code speaks the **Anthropic Messages API**, not Chat Completions, so
  `ANTHROPIC_BASE_URL` is the gateway origin without `/v1`. It also needs real
  streaming, which the gateway passes through unbuffered.

## Endpoints

| Route | Purpose |
| --- | --- |
| `GET /` | control panel |
| `HEAD /` | liveness probe (Claude Code sends this on startup) |
| `GET /v1/models` | alias list with load state and context length |
| `POST /v1/responses` | OpenAI Responses — Codex |
| `POST /v1/chat/completions` | OpenAI Chat Completions — Qwen Code, Continue, Copilot |
| `POST /v1/messages` | Anthropic Messages — Claude Code |
| `POST /v1/messages/count_tokens` | Anthropic token counting |
| `ANY /v1/*` | passthrough to the resolved backend |
| `GET /healthz` | health, mode, loaded models |
| `GET /admin/status` | per-backend detail |
| `POST /admin/load/{alias}`, `/admin/unload/{alias}` | load and free models |
| `POST /admin/mode/{mode}` | exclusive / concurrent at runtime |
| `POST /admin/reload` | re-read `models.yaml` |
| `POST /admin/shutdown` | stop every backend and exit |
| `GET/POST /api/*` | everything the control panel uses (models, library, network, clients, launch, diagnostics) |

Replies carry `X-Unsloth-Backend` and `X-Unsloth-Served-Model`. Aliases resolve
loosely: `qwen3-coder`, `unsloth/Qwen3.6-35B-A3B-GGUF`, `Qwen3.6-35B-A3B-GGUF`
and `openai:qwen3-coder` all reach the same backend. A model id the fleet does
not know — `claude-sonnet-4-6`, for example — is served by the default model and
logged; set `gateway.unknownModel: error` to get a 404 instead.

## Keys

`gateway.apiKey` in `models.yaml` (or `GATEWAY_API_KEY`) is what clients send.
It is generated on first run. Each backend's own `sk-unsloth-…` key is captured
from `unsloth run` output and swapped in per request, so the backend key never
leaves this machine.

## Model fleet

`models.yaml` is written by the control panel and is still hand-editable:

```yaml
models:
  - alias: qwen3-coder
    repo: unsloth/Qwen3-Coder-30B-A3B-Instruct-GGUF
    quant: UD-Q4_K_XL
    port: 8801
    contextLength: 262144
    reasoning: off        # on | off
    disableTools: true    # the coding agent runs its own tools
    extraArgs: []         # passed straight to `unsloth run`
    env: {}               # e.g. { CUDA_VISIBLE_DEVICES: "0" }
```

Models are discovered in the Hugging Face hub cache — `$HF_HUB_CACHE`,
`$HF_HOME/hub`, `$XDG_CACHE_HOME/huggingface/hub`, then
`~/.cache/huggingface/hub` — and in the LM Studio folder. Add more with
`gateway.extraModelPaths`.

## Tests

```bash
dotnet test
```

110 tests cover fleet-file validation and rewriting, GGUF header parsing and
cache scanning, catalog grouping, every generated client config (including that
the Codex block stays valid TOML when appended to an existing file), gateway
routing and authentication against a stub backend served over real HTTP, the
whole control API, LAN URL building, and translation-key parity in both
languages, plus a guard that no component code detaches from the Blazor dispatcher.

## Layout

```
models.yaml                          fleet definition — written by the panel, editable by hand
publish.ps1                          builds dist\Padra Platform Launcher.exe + Padra.Server.exe
run-server.ps1 / run-server.sh       headless gateway from source
src/Padra.Core/Configuration/        models.yaml load / validate / mutate / save, user settings
src/Padra.Core/Discovery/            local GGUF scan, GGUF header reader, Hugging Face catalog
src/Padra.Core/Networking/           LAN addresses, URLs, firewall
src/Padra.Core/Runtime/              backend processes, the fleet, activity log, orphan cleanup
src/Padra.Core/Clients/              Codex / Qwen / Claude / Continue / VS Code config writer
src/Padra.Web/Endpoints/             the /v1, /admin and /api surfaces
src/Padra.Web/Components/            the Blazor control panel
src/Padra.Web/UiStrings*.resx        every user-facing string
src/Padra.Desktop/                   WPF + WebView2 window and gateway supervisor (Windows only)
tests/Padra.Tests/                   xunit suite
legacy/python/                       the previous Python implementation, kept for reference
docs/GLOBAL-RULES.md                 owner-mandated rules, binding on every change
```

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `the unsloth command was not found` | install the Unsloth CLI, or set `gateway.unslothBin` to its full path |
| Codex shows the ChatGPT sign-in picker | use `codex --profile <alias>`, not `--oss` |
| 404 unknown model | `GET /v1/models` for the exact list |
| 503 backend_start_error | the message carries the last 30 lines of `unsloth run` output |
| Another machine cannot connect | share on the LAN, add the firewall rule, and send it the config bundle |
| The panel opens from another machine but is refused | append `?key=<gateway key>` once |
| Claude Code keeps asking to log in | reinstall the configs; the VS Code extension needs `claudeCode.environmentVariables` |
| The window says WebView2 is missing | install the runtime, or use the button to open the panel in your browser |
| Port already in use | change it in the Network panel, or stop the other server |
| Nothing on screen and no window | read `padra-launcher.log` next to the executable |
