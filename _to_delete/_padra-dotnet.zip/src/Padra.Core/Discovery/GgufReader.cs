using System.Buffers.Binary;
using System.Text;

namespace Padra.Core.Discovery;

/// <summary>What the GGUF header says about a model file.</summary>
public sealed record GgufMetadata(string? Architecture, int? ContextLength)
{
    public static readonly GgufMetadata Empty = new(null, null);
}

/// <summary>
/// Minimal GGUF metadata reader.
/// <para>
/// Only the key/value header is parsed, and only until the architecture and its
/// context length are known, so reading a 20 GB model costs a few hundred KB.
/// Nothing here throws: an unreadable or non-GGUF file yields empty metadata.
/// </para>
/// </summary>
public static class GgufReader
{
    private const long ScanLimit = 32L * 1024 * 1024;
    private static readonly byte[] Magic = "GGUF"u8.ToArray();

    private enum ValueType
    {
        UInt8 = 0, Int8 = 1, UInt16 = 2, Int16 = 3, UInt32 = 4, Int32 = 5,
        Float32 = 6, Bool = 7, String = 8, Array = 9, UInt64 = 10, Int64 = 11,
        Float64 = 12,
    }

    public static GgufMetadata Read(string path)
    {
        try
        {
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite,
                bufferSize: 1 << 16, FileOptions.SequentialScan);
            return Read(stream);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException
                                       or NotSupportedException or ArgumentException)
        {
            return GgufMetadata.Empty;
        }
    }

    public static GgufMetadata Read(Stream stream)
    {
        try
        {
            var reader = new Cursor(stream);
            var magic = reader.Read(4);
            if (!magic.SequenceEqual(Magic))
            {
                return GgufMetadata.Empty;
            }

            var version = reader.UInt32();
            if (version > 0xFFFF)
            {
                reader.BigEndian = true;
                version = BinaryPrimitives.ReverseEndianness(version);
            }

            if (version < 2)
            {
                return GgufMetadata.Empty;
            }

            reader.UInt64();                          // tensor count
            var pairs = (long)reader.UInt64();
            if (pairs is < 0 or > 100_000)
            {
                return GgufMetadata.Empty;
            }

            string? architecture = null;
            var contexts = new Dictionary<string, int>(StringComparer.Ordinal);

            for (var index = 0; index < pairs; index++)
            {
                var key = reader.String();
                var value = reader.Value((ValueType)reader.UInt32());

                if (key == "general.architecture" && value is string text)
                {
                    architecture = text;
                }
                else if (key.EndsWith(".context_length", StringComparison.Ordinal) &&
                         value is long number && number is > 0 and <= int.MaxValue)
                {
                    contexts[key] = (int)number;
                }

                if (architecture is not null && contexts.ContainsKey($"{architecture}.context_length"))
                {
                    break;
                }
            }

            int? context = null;
            if (architecture is not null && contexts.TryGetValue($"{architecture}.context_length", out var exact))
            {
                context = exact;
            }
            else if (contexts.Count > 0)
            {
                context = contexts.Values.First();
            }

            return new GgufMetadata(architecture, context);
        }
        catch (Exception ex) when (ex is EndOfStreamException or IOException or
                                       InvalidDataException or OverflowException)
        {
            return GgufMetadata.Empty;
        }
    }

    /// <summary>Sequential little/big-endian reader with a hard budget.</summary>
    private sealed class Cursor(Stream stream)
    {
        private long _consumed;

        public bool BigEndian { get; set; }

        public byte[] Read(int count)
        {
            if (_consumed + count > ScanLimit)
            {
                throw new InvalidDataException("gguf metadata exceeds the scan limit");
            }

            var buffer = new byte[count];
            var read = 0;
            while (read < count)
            {
                var chunk = stream.Read(buffer, read, count - read);
                if (chunk == 0)
                {
                    throw new EndOfStreamException("truncated gguf metadata");
                }

                read += chunk;
            }

            _consumed += count;
            return buffer;
        }

        public void Skip(long count)
        {
            if (_consumed + count > ScanLimit)
            {
                throw new InvalidDataException("gguf metadata exceeds the scan limit");
            }

            if (stream.CanSeek)
            {
                if (stream.Seek(count, SeekOrigin.Current) > stream.Length)
                {
                    throw new EndOfStreamException("truncated gguf metadata");
                }
            }
            else
            {
                var remaining = count;
                while (remaining > 0)
                {
                    var chunk = (int)Math.Min(remaining, 1 << 16);
                    Read(chunk);
                    remaining -= chunk;
                    _consumed -= chunk;   // Read already counted it
                }
            }

            _consumed += count;
        }

        public uint UInt32()
        {
            var bytes = Read(4);
            return BigEndian
                ? BinaryPrimitives.ReadUInt32BigEndian(bytes)
                : BinaryPrimitives.ReadUInt32LittleEndian(bytes);
        }

        public ulong UInt64()
        {
            var bytes = Read(8);
            return BigEndian
                ? BinaryPrimitives.ReadUInt64BigEndian(bytes)
                : BinaryPrimitives.ReadUInt64LittleEndian(bytes);
        }

        public string String()
        {
            var length = UInt64();
            if (length > 1 << 22)
            {
                throw new InvalidDataException("implausible gguf string length");
            }

            return Encoding.UTF8.GetString(Read((int)length));
        }

        public object? Value(ValueType type)
        {
            switch (type)
            {
                case ValueType.UInt8: return (long)Read(1)[0];
                case ValueType.Int8: return (long)(sbyte)Read(1)[0];
                case ValueType.Bool: return Read(1)[0] != 0;
                case ValueType.UInt16:
                {
                    var bytes = Read(2);
                    return (long)(BigEndian
                        ? BinaryPrimitives.ReadUInt16BigEndian(bytes)
                        : BinaryPrimitives.ReadUInt16LittleEndian(bytes));
                }

                case ValueType.Int16:
                {
                    var bytes = Read(2);
                    return (long)(BigEndian
                        ? BinaryPrimitives.ReadInt16BigEndian(bytes)
                        : BinaryPrimitives.ReadInt16LittleEndian(bytes));
                }

                case ValueType.UInt32: return (long)UInt32();
                case ValueType.Int32: return (long)(int)UInt32();
                case ValueType.Float32: Skip(4); return null;
                case ValueType.UInt64: return (long)UInt64();
                case ValueType.Int64: return (long)UInt64();
                case ValueType.Float64: Skip(8); return null;
                case ValueType.String: return String();
                case ValueType.Array:
                {
                    var itemType = (ValueType)UInt32();
                    var count = (long)UInt64();
                    var width = FixedWidth(itemType);
                    if (width > 0)
                    {
                        Skip(width * count);          // skip the payload wholesale
                        return null;
                    }

                    for (var index = 0L; index < count; index++)
                    {
                        Value(itemType);
                    }

                    return null;
                }

                default:
                    throw new InvalidDataException($"unknown gguf value type {(int)type}");
            }
        }

        private static int FixedWidth(ValueType type) => type switch
        {
            ValueType.UInt8 or ValueType.Int8 or ValueType.Bool => 1,
            ValueType.UInt16 or ValueType.Int16 => 2,
            ValueType.UInt32 or ValueType.Int32 or ValueType.Float32 => 4,
            ValueType.UInt64 or ValueType.Int64 or ValueType.Float64 => 8,
            _ => 0,
        };
    }
}
