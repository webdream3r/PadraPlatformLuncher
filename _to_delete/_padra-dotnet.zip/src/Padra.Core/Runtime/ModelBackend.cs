using System.Diagnostics;
using System.Globalization;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.RegularExpressions;
using Padra.Core.Configuration;
using Padra.Core.Networking;

namespace Padra.Core.Runtime;

public sealed record BackendStatus(
    string Alias,
    string Repo,
    string Quant,
    string ModelSpec,
    string ServedId,
    string BaseUrl,
    int Port,
    bool Running,
    bool External,
    int? Pid,
    bool HaveApiKey,
    int? ContextLength,
    DateTimeOffset? LastUsed,
    string LastError);

/// <summary>Raised when a backend cannot be started; the message reaches the client.</summary>
public sealed class BackendStartException(string message) : Exception(message);

/// <summary>A single <c>unsloth run</c> process serving exactly one model.</summary>
public sealed partial class ModelBackend : IDisposable
{
    private const int LogTail = 200;

    [GeneratedRegex(@"sk-unsloth-[A-Za-z0-9._\-]{8,}")]
    private static partial Regex UnslothKey();

    private readonly ActivityLog _log;
    private readonly OrphanRegistry? _registry;
    private readonly HttpClient _probeClient;
    private readonly Queue<string> _tail = new();
    private readonly object _tailLock = new();
    private readonly string? _configuredKey;

    private Process? _process;

    public ModelBackend(
        ModelOptions options,
        GatewayOptions gateway,
        ActivityLog log,
        OrphanRegistry? registry = null,
        HttpClient? probeClient = null)
    {
        Options = options.Clone();
        _log = log;
        _registry = registry;
        _probeClient = probeClient ?? new HttpClient { Timeout = TimeSpan.FromSeconds(10) };

        UnslothBin = Environment.GetEnvironmentVariable("UNSLOTH_BIN") ?? gateway.UnslothBin;
        StartTimeout = TimeSpan.FromSeconds(Math.Max(5, gateway.StartTimeout));

        _configuredKey = FirstNonEmpty(
            options.ApiKey,
            Environment.GetEnvironmentVariable(
                $"UNSLOTH_API_KEY_{options.Alias.ToUpperInvariant().Replace('-', '_')}"),
            Environment.GetEnvironmentVariable("UNSLOTH_API_KEY"));
        ApiKey = _configuredKey;

        ServedId = string.IsNullOrEmpty(options.ServedId) ? options.ModelSpec : options.ServedId;
    }

    public ModelOptions Options { get; }

    public string Alias => Options.Alias;

    public int Port => Options.Port;

    public string UnslothBin { get; set; }

    public TimeSpan StartTimeout { get; set; }

    public string ServedId { get; private set; }

    public string? ApiKey { get; private set; }

    public bool External { get; private set; }

    public DateTimeOffset? LastUsed { get; set; }

    public string LastError { get; private set; } = string.Empty;

    public string BaseUrl => $"http://{NetworkHosts.ForUrl(Options.Host)}:{Options.Port}";

    public bool IsRunning => External || (_process is { HasExited: false });

    /// <summary>True when a reloaded entry describes the same running process.</summary>
    public bool Matches(ModelOptions other) =>
        Options.Repo == other.Repo &&
        Options.Quant == other.Quant &&
        Options.Port == other.Port &&
        Options.Host == other.Host &&
        Options.DisableTools == other.DisableTools &&
        Options.Reasoning == other.Reasoning &&
        Options.ContextLength == other.ContextLength &&
        Options.ExtraArgs.SequenceEqual(other.ExtraArgs);

    // ------------------------------------------------------------- command #
    public IReadOnlyList<string> BuildArguments()
    {
        var arguments = new List<string>
        {
            "run",
            "--model", Options.ModelSpec,
            "-H", Options.Host,
            "-p", Options.Port.ToString(CultureInfo.InvariantCulture),
        };

        if (Options.ContextLength is > 0)
        {
            arguments.Add("-c");
            arguments.Add(Options.ContextLength.Value.ToString(CultureInfo.InvariantCulture));
        }

        if (Options.DisableTools && !Options.ExtraArgs.Contains("--disable-tools"))
        {
            arguments.Add("--disable-tools");
        }

        if (Options.Reasoning.Length > 0 && !Options.ExtraArgs.Contains("--reasoning"))
        {
            arguments.Add("--reasoning");
            arguments.Add(Options.Reasoning);
        }

        // Never block on the confirmation shown for non-local binds.
        if (!Options.ExtraArgs.Contains("-y") && !Options.ExtraArgs.Contains("--yes"))
        {
            arguments.Add("--yes");
        }

        arguments.AddRange(Options.ExtraArgs);
        return arguments;
    }

    public string CommandLine() => $"{UnslothBin} {string.Join(' ', BuildArguments())}";

    // ------------------------------------------------------------ lifecycle #
    /// <summary>Attach to an existing server or spawn one, then wait until it answers.</summary>
    public async Task StartAsync(CancellationToken token = default)
    {
        if (IsRunning)
        {
            return;
        }

        LastError = string.Empty;

        var (reachable, ids) = await ProbeAsync(TimeSpan.FromSeconds(2.5), token).ConfigureAwait(false);
        if (reachable && ids is { Count: > 0 })
        {
            External = true;
            AdoptServedId(ids);
            _log.Write($"{Alias}: attached to the server already on :{Port} (served id: {ServedId})");
            return;
        }

        if (reachable && string.IsNullOrEmpty(ApiKey))
        {
            throw new BackendStartException(
                $"{Alias}: port {Port} is already in use by a server that needs an API key. " +
                $"Set `apiKey` for this model in models.yaml, or free the port.");
        }

        if (ResolveBinary() is null)
        {
            throw new BackendStartException(
                $"the `{UnslothBin}` command was not found. Install the Unsloth CLI first — " +
                "Windows: irm https://unsloth.ai/install.ps1 | iex, " +
                "macOS/Linux: curl -fsSL https://unsloth.ai/install.sh | sh");
        }

        var start = new ProcessStartInfo(UnslothBin)
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            WorkingDirectory = Environment.CurrentDirectory,
        };

        foreach (var argument in BuildArguments())
        {
            start.ArgumentList.Add(argument);
        }

        foreach (var (key, value) in Options.Env)
        {
            start.Environment[key] = value;
        }

        _log.Write($"{Alias}: starting -> {CommandLine()}");

        try
        {
            _process = Process.Start(start)
                       ?? throw new BackendStartException($"{Alias}: `{UnslothBin}` did not start");
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            throw new BackendStartException($"{Alias}: could not start `{UnslothBin}`: {ex.Message}");
        }

        _process.OutputDataReceived += OnOutput;
        _process.ErrorDataReceived += OnOutput;
        _process.BeginOutputReadLine();
        _process.BeginErrorReadLine();
        _process.StandardInput.Close();
        _registry?.Add(Alias, _process.Id, Port);

        var deadline = DateTimeOffset.UtcNow + StartTimeout;
        var sawServer = false;

        while (DateTimeOffset.UtcNow < deadline)
        {
            token.ThrowIfCancellationRequested();

            if (_process.HasExited)
            {
                var code = _process.ExitCode;
                Forget();
                throw new BackendStartException(
                    $"{Alias}: `unsloth run` exited with code {code}{Environment.NewLine}{Tail()}");
            }

            var (up, served) = await ProbeAsync(TimeSpan.FromSeconds(5), token).ConfigureAwait(false);
            sawServer |= up;
            if (served is { Count: > 0 })
            {
                AdoptServedId(served);
                _log.Write($"{Alias}: ready on :{Port} (served id: {ServedId})");
                return;
            }

            await Task.Delay(TimeSpan.FromSeconds(1.5), token).ConfigureAwait(false);
        }

        Stop();
        var detail = sawServer && string.IsNullOrEmpty(ApiKey)
            ? "the backend answered but rejected the API key"
            : $"it did not answer on {BaseUrl}";
        throw new BackendStartException(
            $"{Alias}: not ready after {StartTimeout.TotalSeconds:F0}s — {detail}." +
            $"{Environment.NewLine}{Tail()}");
    }

    public void Stop()
    {
        if (External)
        {
            _log.Write($"{Alias}: detaching (the server was not started here)");
            External = false;
            return;
        }

        var process = _process;
        if (process is null)
        {
            return;
        }

        if (!process.HasExited)
        {
            _log.Write($"{Alias}: stopping pid {process.Id}");
            ProcessTree.Terminate(process, _log);
        }

        Forget();
    }

    public BackendStatus Status()
    {
        int? pid = null;
        try
        {
            if (_process is { HasExited: false })
            {
                pid = _process.Id;
            }
        }
        catch (InvalidOperationException)
        {
            pid = null;
        }

        return new BackendStatus(
            Alias,
            Options.Repo,
            Options.Quant,
            Options.ModelSpec,
            ServedId,
            BaseUrl,
            Port,
            IsRunning,
            External,
            pid,
            !string.IsNullOrEmpty(ApiKey),
            Options.ContextLength,
            LastUsed,
            LastError);
    }

    public void RecordError(string message) => LastError = message;

    public void ClearError() => LastError = string.Empty;

    public void Dispose()
    {
        _process?.Dispose();
        _process = null;
    }

    // --------------------------------------------------------------- plumb #
    /// <summary>`(reachable, served ids)`. Ids are null when the answer was rejected.</summary>
    private async Task<(bool Reachable, IReadOnlyList<string>? Ids)> ProbeAsync(
        TimeSpan timeout, CancellationToken token)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, $"{BaseUrl}/v1/models");
        if (!string.IsNullOrEmpty(ApiKey))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ApiKey);
            request.Headers.TryAddWithoutValidation("x-api-key", ApiKey);
        }

        using var timer = CancellationTokenSource.CreateLinkedTokenSource(token);
        timer.CancelAfter(timeout);

        try
        {
            using var response = await _probeClient.SendAsync(request, timer.Token).ConfigureAwait(false);
            if (!response.IsSuccessStatusCode)
            {
                return (true, null);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(timer.Token)
                .ConfigureAwait(false);
            using var document = await JsonDocument.ParseAsync(stream, cancellationToken: timer.Token)
                .ConfigureAwait(false);

            if (!document.RootElement.TryGetProperty("data", out var data) ||
                data.ValueKind != JsonValueKind.Array)
            {
                return (true, null);
            }

            var ids = data.EnumerateArray()
                .Select(item => item.TryGetProperty("id", out var id) ? id.GetString() : null)
                .Where(id => !string.IsNullOrEmpty(id))
                .Select(id => id!)
                .ToList();
            return (true, ids);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested)
        {
            return (false, null);
        }
        catch (Exception ex) when (ex is HttpRequestException or JsonException or IOException)
        {
            return (false, null);
        }
    }

    private void AdoptServedId(IReadOnlyList<string> ids)
    {
        if (ids.Count == 0)
        {
            return;
        }

        foreach (var candidate in new[]
                 {
                     ServedId, Options.ModelSpec, Options.Repo, Options.Repo.Split('/')[^1],
                 })
        {
            if (ids.Contains(candidate, StringComparer.Ordinal))
            {
                ServedId = candidate;
                return;
            }
        }

        ServedId = ids[0];
    }

    private void OnOutput(object sender, DataReceivedEventArgs args)
    {
        if (args.Data is null)
        {
            return;
        }

        lock (_tailLock)
        {
            _tail.Enqueue(args.Data);
            while (_tail.Count > LogTail)
            {
                _tail.Dequeue();
            }
        }

        if (string.IsNullOrEmpty(ApiKey))
        {
            var match = UnslothKey().Match(args.Data);
            if (match.Success)
            {
                ApiKey = match.Value;
                _log.Write($"{Alias}: captured the backend API key");
            }
        }
    }

    private string Tail(int lines = 30)
    {
        lock (_tailLock)
        {
            return string.Join(Environment.NewLine, _tail.TakeLast(lines));
        }
    }

    private void Forget()
    {
        if (_process is not null)
        {
            try
            {
                _registry?.Remove(_process.Id);
            }
            catch (InvalidOperationException)
            {
                // The process object was never started.
            }

            _process.Dispose();
            _process = null;
        }

        ApiKey = _configuredKey;
    }

    private string? ResolveBinary()
    {
        if (File.Exists(UnslothBin))
        {
            return UnslothBin;
        }

        return ExecutableFinder.Find(UnslothBin);
    }

    private static string? FirstNonEmpty(params string?[] values) =>
        values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v));
}

/// <summary>PATH lookup that also understands Windows' executable extensions.</summary>
public static class ExecutableFinder
{
    public static bool IsWindows => RuntimeInformation.IsOSPlatform(OSPlatform.Windows);

    public static string? Find(string command)
    {
        if (command.Contains(System.IO.Path.DirectorySeparatorChar) ||
            command.Contains(System.IO.Path.AltDirectorySeparatorChar))
        {
            return File.Exists(command) ? System.IO.Path.GetFullPath(command) : null;
        }

        var extensions = IsWindows
            ? (Environment.GetEnvironmentVariable("PATHEXT") ?? ".COM;.EXE;.BAT;.CMD")
                .Split(';', StringSplitOptions.RemoveEmptyEntries)
            : new[] { string.Empty };

        var directories = (Environment.GetEnvironmentVariable("PATH") ?? string.Empty)
            .Split(System.IO.Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries);

        foreach (var directory in directories)
        {
            foreach (var extension in extensions)
            {
                string candidate;
                try
                {
                    candidate = System.IO.Path.Combine(directory.Trim(), command + extension);
                }
                catch (ArgumentException)
                {
                    continue;   // the PATH entry contains invalid characters
                }

                if (File.Exists(candidate))
                {
                    return candidate;
                }
            }
        }

        return null;
    }
}
