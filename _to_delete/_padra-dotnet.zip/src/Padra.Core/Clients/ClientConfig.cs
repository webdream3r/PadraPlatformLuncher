using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using Padra.Core.Configuration;

namespace Padra.Core.Clients;

/// <summary>The coding agents this launcher can configure.</summary>
public enum ClientTarget
{
    Codex,
    Qwen,
    Claude,
    Continue,
    VsCode,
}

/// <summary>One model, as the client configuration files see it.</summary>
public sealed record ClientModel(string Alias, string Repo, string Quant, int ContextLength)
{
    public string Spec => string.IsNullOrEmpty(Quant) ? Repo : $"{Repo}:{Quant}";
}

/// <summary>Everything the generators need, independent of where it came from.</summary>
public sealed class ClientContext
{
    public const int DefaultContext = 131072;

    public required string BaseUrl { get; init; }

    public required string ApiKey { get; init; }

    public required IReadOnlyList<ClientModel> Models { get; init; }

    public required string DefaultAlias { get; init; }

    public CodexWireApi WireApi { get; init; } = CodexWireApi.Responses;

    public string ProjectDirectory { get; init; } = Environment.CurrentDirectory;

    /// <summary>Claude Code appends <c>/v1/...</c> itself, so it wants the bare origin.</summary>
    public string AnthropicBase =>
        BaseUrl.EndsWith("/v1", StringComparison.Ordinal) ? BaseUrl[..^3] : BaseUrl;

    public static ClientContext FromFleet(FleetOptions options, string? baseUrl = null,
        string? projectDirectory = null)
    {
        var models = options.Models
            .Select(m => new ClientModel(m.Alias, m.Repo, m.Quant, m.ContextLength ?? DefaultContext))
            .ToList();

        return new ClientContext
        {
            BaseUrl = string.IsNullOrWhiteSpace(baseUrl) ? DefaultBaseUrl(options) : baseUrl!,
            ApiKey = Environment.GetEnvironmentVariable("GATEWAY_API_KEY") is { Length: > 0 } key
                ? key
                : options.Gateway.ApiKey,
            Models = models,
            DefaultAlias = options.Gateway.DefaultModel.Length > 0
                ? options.Gateway.DefaultModel
                : models.FirstOrDefault()?.Alias ?? string.Empty,
            WireApi = options.Gateway.WireApi,
            ProjectDirectory = projectDirectory ?? Environment.CurrentDirectory,
        };
    }

    public static string DefaultBaseUrl(FleetOptions options)
    {
        var host = options.Gateway.Host;
        if (Networking.NetworkHosts.IsWildcard(host))
        {
            host = "127.0.0.1";
        }

        return $"http://{Networking.NetworkHosts.ForUrl(host)}:{options.Gateway.Port}/v1";
    }
}

/// <summary>Exactly what an install touched, so the report can be honest.</summary>
public sealed class InstallReport
{
    public List<string> Lines { get; } = new();

    public List<string> Written { get; } = new();

    public List<string> Failed { get; } = new();

    public bool Ok => Failed.Count == 0;

    public void Wrote(string path)
    {
        Written.Add(path);
        Lines.Add($"wrote {path}");
    }

    public void Unchanged(string path) => Lines.Add($"already current {path}");

    public void Removed(string path) => Lines.Add($"removed {path}");

    public void BackedUp(string? path)
    {
        if (path is not null)
        {
            Lines.Add($"backed up {path}");
        }
    }

    public void Note(string message) => Lines.Add(message);

    public void Failure(ClientTarget target, Exception error)
    {
        Failed.Add(target.ToString().ToLowerInvariant());
        Lines.Add($"{target.ToString().ToLowerInvariant()} failed: {error.Message}");
    }
}

/// <summary>
/// Writes the provider settings each coding agent actually reads.
/// <para>
/// Everything is merged rather than overwritten: unrelated keys survive, the
/// previous file is copied to <c>.bak</c>, and running twice changes nothing.
/// </para>
/// </summary>
public static class ClientConfigWriter
{
    public const string CodexProviderId = "unsloth_gw";
    public const string EnvKeyName = "UNSLOTH_GATEWAY_KEY";
    public const string BlockBegin = "# >>> padra-platform-launcher >>>";
    public const string BlockEnd = "# <<< padra-platform-launcher <<<";

    public static readonly IReadOnlyList<ClientTarget> AllTargets =
        Enum.GetValues<ClientTarget>().ToList();

    private static readonly JsonDocumentOptions LenientDocument = new()
    {
        CommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
    };

    private static readonly JsonSerializerOptions Pretty = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        // JsonNode values created from CLR types need a resolver to serialise.
        TypeInfoResolver = new System.Text.Json.Serialization.Metadata.DefaultJsonTypeInfoResolver(),
    };

    public static bool IsWindows => RuntimeInformation.IsOSPlatform(OSPlatform.Windows);

    public static string Slug(ClientTarget target) => target switch
    {
        ClientTarget.VsCode => "vscode",
        _ => target.ToString().ToLowerInvariant(),
    };

    public static bool TryParseTarget(string value, out ClientTarget target)
    {
        target = ClientTarget.Codex;
        foreach (var candidate in AllTargets)
        {
            if (string.Equals(Slug(candidate), value.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                target = candidate;
                return true;
            }
        }

        return false;
    }

    // ================================================================= Codex #
    /// <summary>
    /// The <c>[model_providers.…]</c> table for <c>~/.codex/config.toml</c>.
    /// Only a table is emitted: in TOML every key after a table header belongs to
    /// that table, so appending bare keys to an existing file would silently move
    /// them into whatever section came last.
    /// </summary>
    public static string CodexProviderBlock(ClientContext context) =>
        $"[model_providers.{CodexProviderId}]{Environment.NewLine}" +
        $"name                 = {Toml("Padra Platform Launcher (Unsloth)")}{Environment.NewLine}" +
        $"base_url             = {Toml(context.BaseUrl)}{Environment.NewLine}" +
        $"env_key              = {Toml(EnvKeyName)}{Environment.NewLine}" +
        $"wire_api             = {Toml(context.WireApi.ToString().ToLowerInvariant())}{Environment.NewLine}" +
        $"requires_openai_auth = false{Environment.NewLine}" +
        $"stream_idle_timeout_ms = 600000{Environment.NewLine}";

    public static string CodexRootConfig(ClientContext context)
    {
        var alias = context.DefaultAlias.Length > 0 ? context.DefaultAlias : "your-alias";
        var header = new StringBuilder()
            .AppendLine("# Add this to ~/.codex/config.toml")
            .AppendLine(@"#   Windows: %USERPROFILE%\.codex\config.toml")
            .AppendLine("# Select it per run with `codex --profile <alias>`, or make it the")
            .AppendLine("# default by adding these two keys ABOVE every [table] in that file:")
            .AppendLine($"#   model_provider = {Toml(CodexProviderId)}")
            .AppendLine($"#   model          = {Toml(alias)}")
            .AppendLine("# Do not use `codex --oss`: that flag only selects Ollama or LM Studio.")
            .AppendLine();
        return header + CodexProviderBlock(context);
    }

    /// <summary>
    /// A Codex profile file: <c>~/.codex/&lt;alias&gt;.config.toml</c>. Profiles are separate
    /// files whose keys are top-level; <c>[profiles.x]</c> inside config.toml stopped
    /// working in Codex 0.134.0.
    /// </summary>
    public static string CodexProfile(ClientModel model) =>
        $"# {model.Alias} — run with:  codex --profile {model.Alias}{Environment.NewLine}" +
        $"model_provider       = {Toml(CodexProviderId)}{Environment.NewLine}" +
        $"model                = {Toml(model.Alias)}{Environment.NewLine}" +
        $"model_context_window = {model.ContextLength.ToString(CultureInfo.InvariantCulture)}" +
        Environment.NewLine;

    private static void InstallCodex(ClientContext context, InstallReport report)
    {
        var home = Environment.GetEnvironmentVariable("CODEX_HOME") is { Length: > 0 } custom
            ? custom
            : Path.Combine(UserHome(), ".codex");

        var root = Path.Combine(home, "config.toml");
        var existing = File.Exists(root) ? File.ReadAllText(root, Encoding.UTF8) : string.Empty;
        var updated = ReplaceManagedBlock(existing, CodexProviderBlock(context));
        if (updated != existing)
        {
            report.BackedUp(Backup(root));
            WriteText(root, updated);
            report.Wrote(root);
        }
        else
        {
            report.Unchanged(root);
        }

        var keep = context.Models.Select(m => $"{m.Alias}.config.toml").ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var model in context.Models)
        {
            var target = Path.Combine(home, $"{model.Alias}.config.toml");
            var content = CodexProfile(model);
            if (!File.Exists(target) || File.ReadAllText(target, Encoding.UTF8) != content)
            {
                report.BackedUp(Backup(target));
                WriteText(target, content);
                report.Wrote(target);
            }
            else
            {
                report.Unchanged(target);
            }
        }

        // Remove profiles this launcher wrote for models that no longer exist.
        if (Directory.Exists(home))
        {
            foreach (var stale in Directory.GetFiles(home, "*.config.toml"))
            {
                if (keep.Contains(Path.GetFileName(stale)))
                {
                    continue;
                }

                string body;
                try
                {
                    body = File.ReadAllText(stale, Encoding.UTF8);
                }
                catch (IOException)
                {
                    continue;
                }

                if (body.Contains($"model_provider       = \"{CodexProviderId}\"", StringComparison.Ordinal))
                {
                    report.BackedUp(Backup(stale));
                    File.Delete(stale);
                    report.Removed(stale);
                }
            }
        }
    }

    // ============================================================= Qwen Code #
    public static JsonObject QwenSettings(ClientContext context)
    {
        var providers = new JsonArray();
        foreach (var model in context.Models)
        {
            providers.Add(new JsonObject
            {
                ["id"] = model.Alias,
                ["name"] = $"{model.Alias} — Padra (Unsloth)",
                ["description"] = model.Spec.Length > 0 ? model.Spec : model.Alias,
                ["baseUrl"] = context.BaseUrl,
                ["envKey"] = EnvKeyName,
            });
        }

        return new JsonObject
        {
            ["modelProviders"] = new JsonObject { ["openai"] = providers },
            ["env"] = new JsonObject
            {
                [EnvKeyName] = context.ApiKey,
                ["OPENAI_API_KEY"] = context.ApiKey,
                ["OPENAI_BASE_URL"] = context.BaseUrl,
            },
            ["security"] = new JsonObject
            {
                ["auth"] = new JsonObject { ["selectedType"] = "openai" },
            },
            ["model"] = new JsonObject { ["name"] = context.DefaultAlias },
        };
    }

    private static void InstallQwen(ClientContext context, InstallReport report)
    {
        var home = Environment.GetEnvironmentVariable("QWEN_HOME") is { Length: > 0 } custom
            ? custom
            : Path.Combine(UserHome(), ".qwen");
        var target = Path.Combine(home, "settings.json");

        var merged = LoadJsonObject(target, report);
        var fresh = QwenSettings(context);

        var providers = Section(merged, "modelProviders");
        providers["openai"] = fresh["modelProviders"]!["openai"]!.DeepClone();

        var env = Section(merged, "env");
        foreach (var (key, value) in (JsonObject)fresh["env"]!)
        {
            env[key] = value?.DeepClone();
        }

        Section(Section(merged, "security"), "auth")["selectedType"] = "openai";

        if (context.DefaultAlias.Length > 0)
        {
            Section(merged, "model")["name"] = context.DefaultAlias;
        }

        WriteJson(target, merged);
        report.Wrote(target);
    }

    // =========================================================== Claude Code #
    /// <summary>Claude Code talks the Anthropic Messages API to <c>ANTHROPIC_BASE_URL</c>.</summary>
    public static Dictionary<string, string> ClaudeEnvironment(ClientContext context)
    {
        var alias = context.DefaultAlias.Length > 0
            ? context.DefaultAlias
            : context.Models.FirstOrDefault()?.Alias ?? string.Empty;

        var env = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["ANTHROPIC_BASE_URL"] = context.AnthropicBase,
            ["ANTHROPIC_AUTH_TOKEN"] = context.ApiKey,
            ["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1",
            ["API_TIMEOUT_MS"] = "600000",
        };

        if (alias.Length > 0)
        {
            env["ANTHROPIC_MODEL"] = alias;
            env["ANTHROPIC_DEFAULT_HAIKU_MODEL"] = alias;
            env["ANTHROPIC_DEFAULT_SONNET_MODEL"] = alias;
            env["ANTHROPIC_DEFAULT_OPUS_MODEL"] = alias;
        }

        return env;
    }

    public static JsonObject ClaudeSettings(ClientContext context)
    {
        var env = new JsonObject();
        foreach (var (key, value) in ClaudeEnvironment(context))
        {
            env[key] = value;
        }

        var settings = new JsonObject
        {
            ["$schema"] = "https://json.schemastore.org/claude-code-settings.json",
            ["env"] = env,
        };

        if (context.DefaultAlias.Length > 0)
        {
            settings["model"] = context.DefaultAlias;
        }

        return settings;
    }

    private static void InstallClaude(ClientContext context, InstallReport report)
    {
        var target = Path.Combine(UserHome(), ".claude", "settings.json");
        var merged = LoadJsonObject(target, report);

        var env = Section(merged, "env");
        foreach (var (key, value) in ClaudeEnvironment(context))
        {
            env[key] = value;
        }

        // A subscription key would win over the gateway token, so clear it.
        env.Remove("ANTHROPIC_API_KEY");

        if (context.DefaultAlias.Length > 0)
        {
            merged["model"] = context.DefaultAlias;
        }

        WriteJson(target, merged);
        report.Wrote(target);
    }

    // ============================================================== Continue #
    public static string ContinueConfig(ClientContext context)
    {
        var lines = new List<string>
        {
            "# ~/.continue/config.yaml — Continue extension for VS Code and JetBrains",
            "name: padra-unsloth",
            "version: 0.0.1",
            "schema: v1",
            "models:",
        };

        if (context.Models.Count == 0)
        {
            lines.Add("  []");
        }

        foreach (var model in context.Models)
        {
            lines.AddRange(new[]
            {
                $"  - name: {model.Alias}",
                "    provider: openai",
                $"    model: {model.Alias}",
                $"    apiBase: {context.BaseUrl}",
                $"    apiKey: {context.ApiKey}",
                "    defaultCompletionOptions:",
                $"      contextLength: {model.ContextLength.ToString(CultureInfo.InvariantCulture)}",
                "    roles: [chat, edit, apply]",
            });
        }

        return string.Join('\n', lines) + '\n';
    }

    private static void InstallContinue(ClientContext context, InstallReport report)
    {
        var target = Path.Combine(UserHome(), ".continue", "config.yaml");
        var content = ContinueConfig(context);
        if (File.Exists(target) && File.ReadAllText(target, Encoding.UTF8) == content)
        {
            report.Unchanged(target);
            return;
        }

        report.BackedUp(Backup(target));
        WriteText(target, content);
        report.Wrote(target);
    }

    // =============================================================== VS Code #
    /// <summary>Every VS Code family user-settings folder present on this machine.</summary>
    public static IReadOnlyList<string> VsCodeUserDirectories()
    {
        string root;
        if (IsWindows)
        {
            root = Environment.GetEnvironmentVariable("APPDATA")
                   ?? Path.Combine(UserHome(), "AppData", "Roaming");
        }
        else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
        {
            root = Path.Combine(UserHome(), "Library", "Application Support");
        }
        else
        {
            root = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME")
                   ?? Path.Combine(UserHome(), ".config");
        }

        return new[] { "Code", "Code - Insiders", "VSCodium" }
            .Select(flavour => Path.Combine(root, flavour, "User"))
            .Where(Directory.Exists)
            .ToList();
    }

    /// <summary>Keys the Claude Code extension reads before it spawns the CLI.</summary>
    public static JsonObject VsCodeSettings(ClientContext context)
    {
        var variables = new JsonArray();
        foreach (var (key, value) in ClaudeEnvironment(context))
        {
            variables.Add(new JsonObject { ["name"] = key, ["value"] = value });
        }

        return new JsonObject
        {
            ["claudeCode.environmentVariables"] = variables,
            ["claudeCode.disableLoginPrompt"] = true,
        };
    }

    /// <summary><c>chatLanguageModels.json</c> entries for Copilot Chat's custom endpoints.</summary>
    public static JsonArray CopilotModels(ClientContext context)
    {
        var models = new JsonArray();
        foreach (var model in context.Models)
        {
            models.Add(new JsonObject
            {
                ["vendor"] = "customendpoint",
                ["name"] = $"{model.Alias} (Padra)",
                ["id"] = model.Alias,
                ["model"] = model.Alias,
                ["apiType"] = "Chat Completions",
                ["url"] = $"{context.BaseUrl}/chat/completions",
                ["apiKey"] = context.ApiKey,
                ["toolCalling"] = true,
                ["maxInputTokens"] = model.ContextLength,
                ["maxOutputTokens"] = 8192,
            });
        }

        return models;
    }

    public static JsonObject VsCodeTasks(ClientContext context)
    {
        var origin = context.BaseUrl.EndsWith("/v1", StringComparison.Ordinal)
            ? context.BaseUrl[..^3]
            : context.BaseUrl;

        var input = new JsonObject
        {
            ["id"] = "padraModel",
            ["type"] = context.Models.Count > 0 ? "pickString" : "promptString",
            ["description"] = "Model alias served by the gateway",
            ["default"] = context.DefaultAlias.Length > 0 ? context.DefaultAlias : "model",
        };

        if (context.Models.Count > 0)
        {
            var options = new JsonArray();
            foreach (var model in context.Models)
            {
                options.Add(model.Alias);
            }

            input["options"] = options;
        }

        return new JsonObject
        {
            ["version"] = "2.0.0",
            ["tasks"] = new JsonArray
            {
                new JsonObject
                {
                    ["label"] = "Padra: start the gateway",
                    ["type"] = "shell",
                    ["command"] = "Padra.Server --config models.yaml",
                    ["options"] = new JsonObject { ["cwd"] = context.ProjectDirectory },
                    ["isBackground"] = true,
                    ["problemMatcher"] = new JsonArray(),
                    ["presentation"] = new JsonObject
                    {
                        ["panel"] = "dedicated",
                        ["reveal"] = "always",
                    },
                },
                new JsonObject
                {
                    ["label"] = "Padra: gateway status",
                    ["type"] = "shell",
                    ["command"] = $"curl -s -H \"Authorization: Bearer ${{env:{EnvKeyName}}}\" " +
                                  $"{origin}/admin/status",
                    ["problemMatcher"] = new JsonArray(),
                },
                new JsonObject
                {
                    ["label"] = "Padra: Codex against a local model",
                    ["type"] = "shell",
                    ["command"] = "codex --profile ${input:padraModel}",
                    ["problemMatcher"] = new JsonArray(),
                },
                new JsonObject
                {
                    ["label"] = "Padra: Qwen Code against a local model",
                    ["type"] = "shell",
                    ["command"] = "qwen --model ${input:padraModel}",
                    ["problemMatcher"] = new JsonArray(),
                },
                new JsonObject
                {
                    ["label"] = "Padra: Claude Code against a local model",
                    ["type"] = "shell",
                    ["command"] = "claude --model ${input:padraModel}",
                    ["problemMatcher"] = new JsonArray(),
                },
            },
            ["inputs"] = new JsonArray { input },
        };
    }

    private static void InstallVsCode(ClientContext context, InstallReport report)
    {
        var directories = VsCodeUserDirectories();
        if (directories.Count == 0)
        {
            report.Note("no VS Code user folder was found on this machine");
            return;
        }

        foreach (var directory in directories)
        {
            var settingsPath = Path.Combine(directory, "settings.json");
            var settings = LoadJsonObject(settingsPath, report);
            foreach (var (key, value) in VsCodeSettings(context))
            {
                settings[key] = value?.DeepClone();
            }

            WriteJson(settingsPath, settings);
            report.Wrote(settingsPath);

            var modelsPath = Path.Combine(directory, "chatLanguageModels.json");
            var kept = new JsonArray();
            var ours = context.Models.Select(m => m.Alias).ToHashSet(StringComparer.Ordinal);
            foreach (var entry in LoadJsonArray(modelsPath, report))
            {
                if (entry is not JsonObject item)
                {
                    continue;
                }

                var isOurs = item["vendor"]?.GetValue<string>() == "customendpoint" &&
                             (ours.Contains(item["id"]?.GetValue<string>() ?? string.Empty) ||
                              (item["name"]?.GetValue<string>() ?? string.Empty)
                              .EndsWith("(Padra)", StringComparison.Ordinal));
                if (!isOurs)
                {
                    kept.Add(item.DeepClone());
                }
            }

            foreach (var entry in CopilotModels(context))
            {
                kept.Add(entry!.DeepClone());
            }

            WriteJson(modelsPath, kept);
            report.Wrote(modelsPath);
        }
    }

    // ========================================================= shell exports #
    public static string EnvSh(ClientContext context)
    {
        var env = ClaudeEnvironment(context);
        return $"""
            # source this file:  . ./env.sh
            export {EnvKeyName}="{context.ApiKey}"

            # Qwen Code and any OpenAI-compatible client
            export OPENAI_API_KEY="{context.ApiKey}"
            export OPENAI_BASE_URL="{context.BaseUrl}"
            export OPENAI_MODEL="{context.DefaultAlias}"

            # Claude Code (Anthropic Messages API)
            export ANTHROPIC_BASE_URL="{env["ANTHROPIC_BASE_URL"]}"
            export ANTHROPIC_AUTH_TOKEN="{context.ApiKey}"
            export ANTHROPIC_MODEL="{context.DefaultAlias}"

            # Codex reads {EnvKeyName} through env_key in ~/.codex/config.toml

            """;
    }

    public static string EnvPs1(ClientContext context)
    {
        var env = ClaudeEnvironment(context);
        return $"""
            # dot-source this file:  . .\env.ps1
            $env:{EnvKeyName} = "{context.ApiKey}"
            $env:OPENAI_API_KEY = "{context.ApiKey}"
            $env:OPENAI_BASE_URL = "{context.BaseUrl}"
            $env:OPENAI_MODEL = "{context.DefaultAlias}"
            $env:ANTHROPIC_BASE_URL = "{env["ANTHROPIC_BASE_URL"]}"
            $env:ANTHROPIC_AUTH_TOKEN = "{context.ApiKey}"
            $env:ANTHROPIC_MODEL = "{context.DefaultAlias}"

            """;
    }

    public static string BundleReadme(ClientContext context, IEnumerable<ClientTarget> targets)
    {
        var aliases = context.Models.Count > 0
            ? string.Join(", ", context.Models.Select(m => m.Alias))
            : "(none configured yet)";

        return $"""
            Padra Platform Launcher — client configuration
            ==============================================

            Endpoint : {context.BaseUrl}
            Key      : {context.ApiKey}
            Models   : {aliases}
            Included : {string.Join(", ", targets.Select(Slug))}

            Codex        copy codex/config.toml into ~/.codex/config.toml and each
                         <alias>.config.toml into ~/.codex/, then run
                         `codex --profile <alias>`. Export {EnvKeyName} first.
            Qwen Code    copy qwen/settings.json to ~/.qwen/settings.json, then run
                         `qwen --model <alias>`.
            Claude Code  copy claude/settings.json to ~/.claude/settings.json, then run
                         `claude`. It uses the Anthropic Messages API of this gateway.
            Continue     copy continue/config.yaml to ~/.continue/config.yaml.
            VS Code      merge vscode/settings.json into your user settings.json and
                         vscode/chatLanguageModels.json into the file of the same name in
                         the same folder; tasks.json belongs in .vscode/ of a project.
            Shell        `. ./env.sh` (bash/zsh) or `. .\env.ps1` (PowerShell).

            Every machine on the network uses the same key. Keep it private.

            """;
    }

    // =============================================================== compose #
    /// <summary>Relative path -> file content for everything <paramref name="targets"/> covers.</summary>
    public static IReadOnlyDictionary<string, string> GeneratedFiles(
        ClientContext context, IEnumerable<ClientTarget>? targets = null)
    {
        var chosen = (targets ?? AllTargets).Distinct().ToList();
        var files = new Dictionary<string, string>(StringComparer.Ordinal);

        if (chosen.Contains(ClientTarget.Codex))
        {
            files["codex/config.toml"] = CodexRootConfig(context);
            foreach (var model in context.Models)
            {
                files[$"codex/{model.Alias}.config.toml"] = CodexProfile(model);
            }
        }

        if (chosen.Contains(ClientTarget.Qwen))
        {
            files["qwen/settings.json"] = Serialise(QwenSettings(context));
        }

        if (chosen.Contains(ClientTarget.Claude))
        {
            files["claude/settings.json"] = Serialise(ClaudeSettings(context));
        }

        if (chosen.Contains(ClientTarget.Continue))
        {
            files["continue/config.yaml"] = ContinueConfig(context);
        }

        if (chosen.Contains(ClientTarget.VsCode))
        {
            files["vscode/settings.json"] = Serialise(VsCodeSettings(context));
            files["vscode/chatLanguageModels.json"] = Serialise(CopilotModels(context));
            files["vscode/tasks.json"] = Serialise(VsCodeTasks(context));
        }

        files["env.sh"] = EnvSh(context);
        files["env.ps1"] = EnvPs1(context);
        files["README.txt"] = BundleReadme(context, chosen);
        return files;
    }

    public static IReadOnlyList<string> WriteGenerated(
        ClientContext context, string outputDirectory, IEnumerable<ClientTarget>? targets = null)
    {
        var written = new List<string>();
        foreach (var (relative, content) in GeneratedFiles(context, targets))
        {
            var path = Path.Combine(outputDirectory, relative.Replace('/', Path.DirectorySeparatorChar));
            WriteText(path, content);
            written.Add(path);
        }

        return written;
    }

    public static InstallReport Install(ClientContext context, IEnumerable<ClientTarget>? targets = null)
    {
        var report = new InstallReport();
        foreach (var target in (targets ?? AllTargets).Distinct())
        {
            try
            {
                switch (target)
                {
                    case ClientTarget.Codex: InstallCodex(context, report); break;
                    case ClientTarget.Qwen: InstallQwen(context, report); break;
                    case ClientTarget.Claude: InstallClaude(context, report); break;
                    case ClientTarget.Continue: InstallContinue(context, report); break;
                    case ClientTarget.VsCode: InstallVsCode(context, report); break;
                    default: report.Note($"unknown target `{target}` — skipped"); break;
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                report.Failure(target, ex);
            }
        }

        return report;
    }

    // ================================================================ plumb #
    /// <summary>Insert or refresh our marker-delimited block, leaving the rest intact.</summary>
    public static string ReplaceManagedBlock(string existing, string block)
    {
        var body = $"{BlockBegin}{Environment.NewLine}{block.Trim()}{Environment.NewLine}{BlockEnd}{Environment.NewLine}";
        var begin = existing.IndexOf(BlockBegin, StringComparison.Ordinal);
        var end = existing.IndexOf(BlockEnd, StringComparison.Ordinal);

        if (begin >= 0 && end > begin)
        {
            var head = existing[..begin].TrimEnd('\r', '\n');
            var tail = existing[(end + BlockEnd.Length)..].TrimStart('\r', '\n');
            var separator = head.Trim().Length > 0
                ? Environment.NewLine + Environment.NewLine
                : string.Empty;
            return head + separator + body + tail;
        }

        var gap = existing.Trim().Length > 0 ? Environment.NewLine + Environment.NewLine : string.Empty;
        return existing.TrimEnd('\r', '\n') + gap + body;
    }

    /// <summary>Parse JSON that may carry comments and trailing commas (VS Code style).</summary>
    public static JsonNode? ParseLenient(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return null;
        }

        return JsonNode.Parse(text, documentOptions: LenientDocument);
    }

    public static string? Backup(string path)
    {
        if (!File.Exists(path))
        {
            return null;
        }

        var target = path + ".bak";
        File.Copy(path, target, overwrite: true);
        return target;
    }

    public static string UserHome() => Discovery.ModelScanner.UserHome();

    private static JsonObject LoadJsonObject(string path, InstallReport report)
    {
        if (!File.Exists(path))
        {
            return new JsonObject();
        }

        report.BackedUp(Backup(path));
        try
        {
            if (ParseLenient(File.ReadAllText(path, Encoding.UTF8)) is JsonObject parsed)
            {
                return parsed;
            }

            report.Note($"{path} was not a JSON object — it was replaced");
        }
        catch (JsonException)
        {
            report.Note($"{path} was not valid JSON — it was replaced");
        }

        return new JsonObject();
    }

    private static JsonArray LoadJsonArray(string path, InstallReport report)
    {
        if (!File.Exists(path))
        {
            return new JsonArray();
        }

        report.BackedUp(Backup(path));
        try
        {
            if (ParseLenient(File.ReadAllText(path, Encoding.UTF8)) is JsonArray parsed)
            {
                return parsed;
            }
        }
        catch (JsonException)
        {
            report.Note($"{path} was not valid JSON — it was replaced");
        }

        return new JsonArray();
    }

    private static JsonObject Section(JsonObject parent, string name)
    {
        if (parent[name] is JsonObject existing)
        {
            return existing;
        }

        var created = new JsonObject();
        parent[name] = created;
        return created;
    }

    private static string Serialise(JsonNode node) => node.ToJsonString(Pretty) + "\n";

    private static void WriteText(string path, string content)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory))
        {
            Directory.CreateDirectory(directory);
        }

        File.WriteAllText(path, content, new UTF8Encoding(false));
    }

    private static void WriteJson(string path, JsonNode node) => WriteText(path, Serialise(node));

    private static string Toml(string value) =>
        "\"" + value.Replace("\\", "\\\\", StringComparison.Ordinal)
                    .Replace("\"", "\\\"", StringComparison.Ordinal) + "\"";
}
