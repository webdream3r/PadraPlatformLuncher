using Padra.Core.Networking;

namespace Padra.Core.Configuration;

/// <summary>Everything <c>models.yaml</c> can express, already validated.</summary>
public sealed class FleetOptions
{
    public const int DefaultGatewayPort = 8900;
    public const int FirstBackendPort = 8801;
    public const int LastBackendPort = 8999;

    public GatewayOptions Gateway { get; set; } = new();

    public List<ModelOptions> Models { get; set; } = new();

    public FleetOptions Clone() => new()
    {
        Gateway = Gateway.Clone(),
        Models = Models.Select(m => m.Clone()).ToList(),
    };
}

public enum FleetMode
{
    /// <summary>One backend in VRAM at a time; the gateway swaps on demand.</summary>
    Exclusive,

    /// <summary>Every requested backend stays loaded.</summary>
    Concurrent,
}

public enum UnknownModelBehaviour
{
    /// <summary>Serve unlisted model ids with the default model (Claude Code needs this).</summary>
    Default,

    /// <summary>Answer 404 for unlisted model ids.</summary>
    Error,
}

public enum CodexWireApi
{
    Responses,
    Chat,
}

public sealed class GatewayOptions
{
    public string Host { get; set; } = "127.0.0.1";

    public int Port { get; set; } = FleetOptions.DefaultGatewayPort;

    public string ApiKey { get; set; } = string.Empty;

    public FleetMode Mode { get; set; } = FleetMode.Exclusive;

    public string DefaultModel { get; set; } = string.Empty;

    public bool Preload { get; set; }

    /// <summary>Seconds of inactivity before a loaded model is freed. 0 disables it.</summary>
    public int IdleTimeout { get; set; }

    /// <summary>Seconds allowed for one proxied request. Agentic turns are long.</summary>
    public int RequestTimeout { get; set; } = 1800;

    /// <summary>Seconds allowed for <c>unsloth run</c> to load a model.</summary>
    public int StartTimeout { get; set; } = 900;

    public string UnslothBin { get; set; } = "unsloth";

    public CodexWireApi WireApi { get; set; } = CodexWireApi.Responses;

    public UnknownModelBehaviour UnknownModel { get; set; } = UnknownModelBehaviour.Default;

    public bool AutoImport { get; set; } = true;

    public bool AllowLan { get; set; }

    public List<string> ExtraModelPaths { get; set; } = new();

    public bool IsShared => NetworkHosts.IsWildcard(Host);

    public GatewayOptions Clone() => new()
    {
        Host = Host,
        Port = Port,
        ApiKey = ApiKey,
        Mode = Mode,
        DefaultModel = DefaultModel,
        Preload = Preload,
        IdleTimeout = IdleTimeout,
        RequestTimeout = RequestTimeout,
        StartTimeout = StartTimeout,
        UnslothBin = UnslothBin,
        WireApi = WireApi,
        UnknownModel = UnknownModel,
        AutoImport = AutoImport,
        AllowLan = AllowLan,
        ExtraModelPaths = new List<string>(ExtraModelPaths),
    };
}

public sealed class ModelOptions
{
    public string Alias { get; set; } = string.Empty;

    public string Repo { get; set; } = string.Empty;

    public string Quant { get; set; } = string.Empty;

    public int Port { get; set; }

    public string Host { get; set; } = "127.0.0.1";

    public int? ContextLength { get; set; }

    /// <summary>Passed straight to <c>unsloth run</c>.</summary>
    public List<string> ExtraArgs { get; set; } = new();

    public Dictionary<string, string> Env { get; set; } = new(StringComparer.Ordinal);

    /// <summary>Required when an external coding agent runs the tools itself.</summary>
    public bool DisableTools { get; set; } = true;

    /// <summary>"on", "off" or empty to leave the model's own default.</summary>
    public string Reasoning { get; set; } = string.Empty;

    /// <summary>Set to skip capturing the backend key from <c>unsloth run</c> output.</summary>
    public string ApiKey { get; set; } = string.Empty;

    /// <summary>Set to skip <c>/v1/models</c> discovery.</summary>
    public string ServedId { get; set; } = string.Empty;

    public string ModelSpec => string.IsNullOrEmpty(Quant) ? Repo : $"{Repo}:{Quant}";

    public ModelOptions Clone() => new()
    {
        Alias = Alias,
        Repo = Repo,
        Quant = Quant,
        Port = Port,
        Host = Host,
        ContextLength = ContextLength,
        ExtraArgs = new List<string>(ExtraArgs),
        Env = new Dictionary<string, string>(Env, StringComparer.Ordinal),
        DisableTools = DisableTools,
        Reasoning = Reasoning,
        ApiKey = ApiKey,
        ServedId = ServedId,
    };
}

/// <summary>Raised when a fleet file cannot be used as it stands.</summary>
public sealed class FleetFileException : Exception
{
    public FleetFileException(string message) : base(message)
    {
    }

    public FleetFileException(string message, Exception inner) : base(message, inner)
    {
    }
}
