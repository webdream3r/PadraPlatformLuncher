using Padra.Core.Discovery;
using Padra.Core.Runtime;

namespace Padra.Web.Services;

public sealed record LibraryEntry(LocalModel Model, bool InFleet);

public sealed record LibrarySnapshot(
    IReadOnlyList<LibraryEntry> Models,
    long TotalBytes,
    IReadOnlyList<string> Roots,
    DateTimeOffset ScannedAt);

/// <summary>
/// The downloaded-model view the panel shows: a disk scan, cached briefly so
/// switching tabs does not re-walk a cache full of multi-gigabyte files.
/// </summary>
public sealed class ModelLibrary(ModelFleet fleet, HuggingFaceCatalog catalog)
{
    private static readonly TimeSpan Freshness = TimeSpan.FromSeconds(60);

    private readonly SemaphoreSlim _gate = new(1, 1);
    private LibrarySnapshot? _cache;

    public HuggingFaceCatalog Catalog { get; } = catalog;

    public async Task<LibrarySnapshot> LocalAsync(bool refresh = false, CancellationToken token = default)
    {
        await _gate.WaitAsync(token).ConfigureAwait(false);
        try
        {
            if (!refresh && _cache is { } cached &&
                DateTimeOffset.UtcNow - cached.ScannedAt < Freshness)
            {
                return cached;
            }

            var extra = fleet.Gateway.ExtraModelPaths;
            var found = await Task.Run(() => ModelScanner.Scan(extra, token: token), token)
                .ConfigureAwait(false);

            var inFleet = fleet.Options.Models
                .Select(m => (m.Repo.ToLowerInvariant(), m.Quant.ToLowerInvariant()))
                .ToHashSet();

            var entries = found
                .Select(m => new LibraryEntry(m,
                    inFleet.Contains((m.Repo.ToLowerInvariant(), m.Quant.ToLowerInvariant()))))
                .ToList();

            var roots = ModelScanner.HuggingFaceCacheRoots().Where(Directory.Exists)
                .Concat(ModelScanner.LmStudioRoots())
                .ToList();

            _cache = new LibrarySnapshot(entries, entries.Sum(e => e.Model.SizeBytes), roots,
                DateTimeOffset.UtcNow);
            return _cache;
        }
        finally
        {
            _gate.Release();
        }
    }

    public void Invalidate() => _cache = null;

    public async Task<IReadOnlyList<LocalModel>> LocalModelsAsync(CancellationToken token = default)
    {
        var snapshot = await LocalAsync(token: token).ConfigureAwait(false);
        return snapshot.Models.Select(e => e.Model).ToList();
    }
}
