using System.Globalization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using Padra.Core.Clients;
using Padra.Core.Configuration;
using Padra.Core.Discovery;
using Padra.Core.Networking;
using Padra.Core.Runtime;
using Padra.Web.Services;

namespace Padra.Web.Components.Pages;

public enum LibraryTab
{
    Local,
    Catalog,
}

/// <summary>
/// The control panel. Everything is server-side: the component owns a refresh
/// timer, calls the same services the HTTP API uses, and never duplicates
/// business logic in the browser.
/// </summary>
public sealed partial class Panel
{
    private static readonly TimeSpan RefreshInterval = TimeSpan.FromSeconds(2.5);
    private static readonly TimeSpan NoticeLifetime = TimeSpan.FromSeconds(6);

    private PeriodicTimer? _timer;
    private CancellationTokenSource? _refreshLoop;
    private DateTimeOffset _noticeShownAt = DateTimeOffset.MinValue;

    private string Error { get; set; } = string.Empty;

    private string Notice { get; set; } = string.Empty;

    private bool Busy { get; set; }

    private LibraryTab Tab { get; set; } = LibraryTab.Local;

    private string Search { get; set; } = string.Empty;

    private string Scope { get; set; } = "local";

    private string ProjectFolder { get; set; } = string.Empty;

    private string LaunchAlias { get; set; } = string.Empty;

    private bool ShareOnLan { get; set; }

    private int PortInput { get; set; }

    private int IdleInput { get; set; }

    private string Warnings { get; set; } = string.Empty;

    private HashSet<string> SelectedTargets { get; set; } = new(StringComparer.Ordinal);

    private IReadOnlyList<LibraryEntry> LocalModels { get; set; } = Array.Empty<LibraryEntry>();

    private long LocalBytes { get; set; }

    private IReadOnlyList<CatalogRepo> CatalogRepos { get; set; } = Array.Empty<CatalogRepo>();

    private HashSet<string> DownloadedRepos { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    private CatalogRepo? SelectedRepo { get; set; }

    private IReadOnlyList<LogEntry> Entries { get; set; } = Array.Empty<LogEntry>();

    private long LogFloor { get; set; }

    private EndpointMap Endpoints { get; set; } = default!;

    private string CurrentCulture => CultureInfo.CurrentUICulture.Name;

    private int LoadedCount => Fleet.Backends.Count(b => b.IsRunning);

    private string LocalUrl => ClientContext.DefaultBaseUrl(Fleet.Options);

    private string StatusText
    {
        get
        {
            var loaded = Fleet.Backends.Where(b => b.IsRunning).Select(b => b.Alias).ToList();
            return loaded.Count > 0
                ? L["status.running_with", string.Join(L["format.list_separator"].Value, loaded)].Value
                : L["status.running_idle"].Value;
        }
    }

    private string Summary =>
        $"{L["footer.models_loaded", CultureFormat.Number(LoadedCount), CultureFormat.Number(Fleet.Options.Models.Count)].Value}" +
        $" · {L["footer.updated", CultureFormat.Time(DateTimeOffset.Now)].Value}";

    protected override async Task OnInitializedAsync()
    {
        var settings = Settings.Snapshot();
        SelectedTargets = settings.InstallTargets.ToHashSet(StringComparer.Ordinal);
        ProjectFolder = settings.ProjectFolder;
        LaunchAlias = Fleet.Options.Models.Any(m => m.Alias == settings.SelectedAlias)
            ? settings.SelectedAlias
            : Fleet.DefaultAlias;

        RefreshNetworkInputs();
        ShareOnLan = Endpoints.Shared || Fleet.Gateway.AllowLan;
        PortInput = Fleet.Gateway.Port;
        IdleInput = Fleet.Gateway.IdleTimeout;

        Entries = Log.Since(LogFloor);
        UpdateWarnings();

        await LoadLibraryAsync(false);
        StartRefreshLoop();
    }

    private void StartRefreshLoop()
    {
        _refreshLoop = new CancellationTokenSource();
        _timer = new PeriodicTimer(RefreshInterval);
        var token = _refreshLoop.Token;

        _ = Task.Run(async () =>
        {
            try
            {
                while (await _timer.WaitForNextTickAsync(token).ConfigureAwait(false))
                {
                    await InvokeAsync(() =>
                    {
                        Entries = Log.Since(LogFloor);
                        RefreshNetworkInputs();
                        if (Notice.Length > 0 && DateTimeOffset.UtcNow - _noticeShownAt > NoticeLifetime)
                        {
                            Notice = string.Empty;
                        }

                        StateHasChanged();
                    }).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
                // The circuit is closing.
            }
        }, token);
    }

    private void RefreshNetworkInputs() =>
        Endpoints = NetworkInfo.EndpointUrls(Fleet.Gateway.Host, Fleet.Gateway.Port);

    private void UpdateWarnings()
    {
        var parts = new List<string>();
        if (ExecutableFinder.Find(Fleet.Gateway.UnslothBin) is null)
        {
            parts.Add(L["warn.unsloth_missing"]);
        }

        var missing = AgentLauncher.AllAvailability()
            .Where(a => !a.Installed)
            .Select(a => L[$"client.{AgentLauncher.Slug(a.Agent)}"].Value)
            .ToList();
        if (missing.Count > 0)
        {
            parts.Add(L["warn.agents_missing", string.Join(L["format.list_separator"].Value, missing)]);
        }

        Warnings = string.Join(" · ", parts);
    }

    private static string BadgeClass(ModelBackend? backend) => backend switch
    {
        { External: true } => "badge badge-attached",
        { IsRunning: true } => "badge badge-loaded",
        { LastError.Length: > 0 } => "badge badge-failed",
        _ => "badge",
    };

    private static string BadgeKey(ModelBackend? backend) => backend switch
    {
        { External: true } => "state.attached",
        { IsRunning: true } => "state.loaded",
        { LastError.Length: > 0 } => "state.failed",
        _ => "state.idle",
    };

    // ------------------------------------------------------------- actions #
    /// <summary>
    /// Runs one panel action with a busy flag and a single error surface.
    /// <para>
    /// Nothing in this component uses <c>ConfigureAwait(false)</c>: continuations
    /// have to come back on the Blazor dispatcher, and calling
    /// <see cref="ComponentBase.StateHasChanged"/> from a pool thread terminates
    /// the circuit. `PanelDispatcherTests` guards that.
    /// </para>
    /// </summary>
    private async Task RunAsync(Func<Task> action)
    {
        Busy = true;
        Error = string.Empty;
        try
        {
            await action();
        }
        catch (Exception ex) when (ex is FleetFileException or BackendStartException
                                       or CatalogException or IOException
                                       or UnauthorizedAccessException or InvalidOperationException)
        {
            Error = L["error.request", ex.Message];
        }
        finally
        {
            Busy = false;
            Entries = Log.Since(LogFloor);
            StateHasChanged();
        }
    }

    private void ShowNotice(string message)
    {
        Notice = message;
        _noticeShownAt = DateTimeOffset.UtcNow;
    }

    private Task RefreshAsync() => RunAsync(async () =>
    {
        RefreshNetworkInputs();
        UpdateWarnings();
        await LoadLibraryAsync(false);
    });

    private Task LoadAsync(string alias) => RunAsync(async () =>
    {
        var backend = Fleet.Resolve(alias, fallback: false);
        Log.Write(L["log.loading_model", alias]);
        await Fleet.EnsureAsync(backend);
    });

    private Task UnloadAsync(string alias) => RunAsync(async () =>
    {
        var backend = Fleet.Resolve(alias, fallback: false);
        await Fleet.UnloadAsync(backend);
    });

    private Task ActivateAsync(string alias) => RunAsync(async () =>
    {
        var backend = Fleet.Resolve(alias, fallback: false);
        Fleet.SetDefault(backend.Alias);
        Settings.Update(s => s.SelectedAlias = backend.Alias);
        LaunchAlias = backend.Alias;

        if (Fleet.Gateway.Mode == FleetMode.Exclusive)
        {
            foreach (var other in Fleet.Backends.Where(b => b != backend && b.IsRunning).ToList())
            {
                await Fleet.UnloadAsync(other);
            }
        }

        await Fleet.EnsureAsync(backend);
        ShowNotice(L["notice.activated", backend.Alias]);
    });

    private Task RemoveAsync(string alias) => RunAsync(async () =>
    {
        var backend = Fleet.Find(alias);
        if (backend is null)
        {
            return;
        }

        if (backend.IsRunning)
        {
            await Fleet.UnloadAsync(backend);
        }

        var draft = Fleet.Options.Clone();
        FleetFile.RemoveModel(draft, alias);
        ApplyDraft(draft);
        Library.Invalidate();
        Log.Write(L["log.model_removed", alias]);
        await LoadLibraryAsync(false);
    });

    private Task AddAsync(string repo, string quant, int? contextLength) => RunAsync(async () =>
    {
        var draft = Fleet.Options.Clone();
        var entry = FleetFile.AddModel(draft, repo, quant, contextLength: contextLength);
        ApplyDraft(draft);
        Library.Invalidate();
        ShowNotice(L["notice.model_added", entry.Alias]);
        await LoadLibraryAsync(false);
        if (SelectedRepo is { } record)
        {
            await ShowVariantsAsync(record.Repo);
        }
    });

    private void ApplyDraft(FleetOptions draft)
    {
        var validated = FleetFile.Validate(draft);
        FleetFile.Save(Fleet.ConfigPath, validated);
        foreach (var alias in Fleet.Apply(validated))
        {
            Log.Write($"{alias}: stopped because its configuration changed");
        }

        if (!Fleet.Options.Models.Any(m => m.Alias == LaunchAlias))
        {
            LaunchAlias = Fleet.DefaultAlias;
        }
    }

    private async Task LoadLibraryAsync(bool refresh)
    {
        var snapshot = await Library.LocalAsync(refresh);
        LocalModels = snapshot.Models;
        LocalBytes = snapshot.TotalBytes;
        DownloadedRepos = snapshot.Models.Select(m => m.Model.Repo.ToLowerInvariant())
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
    }

    private void SelectTab(LibraryTab tab)
    {
        Tab = tab;
        if (tab == LibraryTab.Catalog && CatalogRepos.Count == 0)
        {
            _ = SearchCatalogAsync();
        }
    }

    private async Task OnSearchKey(KeyboardEventArgs args)
    {
        if (args.Key == "Enter")
        {
            await SearchCatalogAsync();
        }
    }

    private Task SearchCatalogAsync() => RunAsync(async () =>
    {
        CatalogRepos = await Library.Catalog.RepositoriesAsync(Search);
        SelectedRepo = null;
    });

    private Task ShowVariantsAsync(string repo) => RunAsync(async () =>
    {
        var record = await Library.Catalog.VariantsAsync(repo);
        var local = await Library.LocalModelsAsync();
        SelectedRepo = HuggingFaceCatalog.MergeDownloaded(record, local);
    });

    private void ToggleTarget(string slug, bool selected)
    {
        if (selected)
        {
            SelectedTargets.Add(slug);
        }
        else
        {
            SelectedTargets.Remove(slug);
        }

        Settings.Update(s => s.InstallTargets = SelectedTargets.ToList());
    }

    private Task InstallAsync() => RunAsync(async () =>
    {
        if (SelectedTargets.Count == 0)
        {
            Error = L["error.no_targets"];
            return;
        }

        if (Fleet.Options.Models.Count == 0)
        {
            Error = L["error.no_model"];
            return;
        }

        var targets = ClientConfigWriter.AllTargets
            .Where(t => SelectedTargets.Contains(ClientConfigWriter.Slug(t)))
            .ToList();
        var context = Endpoints.Shared && Scope == "lan"
            ? ClientContext.FromFleet(Fleet.Options,
                NetworkInfo.PreferredLanUrl(Fleet.Gateway.Host, Fleet.Gateway.Port),
                System.IO.Path.GetDirectoryName(Fleet.ConfigPath))
            : ClientContext.FromFleet(Fleet.Options, null,
                System.IO.Path.GetDirectoryName(Fleet.ConfigPath));

        var output = System.IO.Path.Combine(
            System.IO.Path.GetDirectoryName(Fleet.ConfigPath) ?? ".", "generated");

        var report = await Task.Run(() =>
        {
            ClientConfigWriter.WriteGenerated(context, output, targets);
            return ClientConfigWriter.Install(context, targets);
        });

        foreach (var line in report.Lines)
        {
            Log.Write(line);
        }

        Settings.Update(s => s.InstallTargets = targets.Select(ClientConfigWriter.Slug).ToList());

        if (report.Ok)
        {
            ShowNotice(L["notice.install_ok", CultureFormat.Number(report.Written.Count),
                context.BaseUrl]);
        }
        else
        {
            Error = L["error.install_failed", string.Join(", ", report.Failed)];
        }
    });

    private Task LaunchAsync(CodingAgent agent) => RunAsync(async () =>
    {
        if (string.IsNullOrWhiteSpace(ProjectFolder))
        {
            Error = L["error.folder", L["value.none"].Value];
            return;
        }

        if (string.IsNullOrWhiteSpace(LaunchAlias))
        {
            Error = L["error.no_model"];
            return;
        }

        var folder = Environment.ExpandEnvironmentVariables(ProjectFolder.Trim());
        if (!Directory.Exists(folder))
        {
            Error = L["error.folder", folder];
            return;
        }

        if (!AgentLauncher.Availability(agent).Installed)
        {
            Error = L[$"dialog.missing.{AgentLauncher.Slug(agent)}"];
            return;
        }

        var context = ClientContext.FromFleet(Fleet.Options, null,
            System.IO.Path.GetDirectoryName(Fleet.ConfigPath));

        // Codex resolves `--profile <alias>` from its own config file, so make sure
        // that file exists before the terminal opens. Installing is idempotent.
        var target = agent switch
        {
            CodingAgent.Codex => ClientTarget.Codex,
            CodingAgent.Qwen => ClientTarget.Qwen,
            _ => ClientTarget.Claude,
        };

        var report = await Task.Run(() => ClientConfigWriter.Install(context, new[] { target }))
            ;
        foreach (var line in report.Lines)
        {
            Log.Write(line);
        }

        Settings.Update(s =>
        {
            s.ProjectFolder = folder;
            s.SelectedAlias = LaunchAlias;
            s.LastAgent = AgentLauncher.Slug(agent);
        });

        var result = await Task.Run(() => AgentLauncher.Launch(
            agent, LaunchAlias, folder,
            AgentLauncher.Environment(agent, context, LaunchAlias),
            AgentLauncher.CommandLine(agent, LaunchAlias), Log));

        if (result.Started)
        {
            Log.Write(L["log.launched", AgentLauncher.Slug(agent), LaunchAlias, folder]);
        }
        else
        {
            Error = L["log.no_terminal", result.ScriptPath];
        }
    });

    private Task ApplyNetworkAsync() => RunAsync(async () =>
    {
        var draft = Fleet.Options.Clone();
        draft.Gateway.AllowLan = ShareOnLan;
        draft.Gateway.Host = ShareOnLan ? "0.0.0.0" : "127.0.0.1";
        draft.Gateway.Port = PortInput;
        draft.Gateway.IdleTimeout = IdleInput;

        if (ShareOnLan && Fleet.ApiKey.Length == 0)
        {
            Error = L["error.no_key_for_lan"];
            return;
        }

        var restart = draft.Gateway.Host != Fleet.Gateway.Host ||
                      draft.Gateway.Port != Fleet.Gateway.Port;
        ApplyDraft(draft);
        RefreshNetworkInputs();
        ShowNotice(restart ? L["notice.restart_required"] : L["notice.saved"]);
        await Task.CompletedTask;
    });

    private Task OpenFirewallAsync() => RunAsync(async () =>
    {
        var result = await FirewallHelper.OpenAsync(Fleet.Gateway.Port);
        Log.Write($"firewall rule for port {Fleet.Gateway.Port}: " +
                  (result.Ok ? "added" : $"not added — run: {result.Command}"));
        if (result.Ok)
        {
            ShowNotice(L["notice.firewall_added"]);
        }
        else
        {
            Error = L["error.firewall", result.Command];
        }
    });

    private Task OnModeChanged(ChangeEventArgs args) => RunAsync(async () =>
    {
        if (Enum.TryParse<FleetMode>(args.Value?.ToString(), out var mode))
        {
            await Fleet.SetModeAsync(mode);
            Log.Write(L["log.mode_changed", L[$"mode.{mode.ToString().ToLowerInvariant()}"].Value]);
        }
    });

    private void OnCultureChanged(ChangeEventArgs args)
    {
        var culture = args.Value?.ToString();
        if (string.IsNullOrWhiteSpace(culture))
        {
            return;
        }

        Settings.Update(s => s.Culture = culture);
        Navigation.NavigateTo(
            $"culture?culture={Uri.EscapeDataString(culture)}&redirect={Uri.EscapeDataString("/")}",
            forceLoad: true);
    }

    private void ClearLog() => LogFloor = Log.Cursor;

    private async Task Copy(string text, string messageKey)
    {
        if (string.IsNullOrEmpty(text))
        {
            return;
        }

        try
        {
            await Js.InvokeVoidAsync("navigator.clipboard.writeText", text);
            Log.Write(L[messageKey]);
        }
        catch (JSException)
        {
            Error = L["error.clipboard", text];
        }
        catch (InvalidOperationException)
        {
            Error = L["error.clipboard", text];
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_refreshLoop is not null)
        {
            await _refreshLoop.CancelAsync().ConfigureAwait(false);
            _refreshLoop.Dispose();
        }

        _timer?.Dispose();
    }
}
