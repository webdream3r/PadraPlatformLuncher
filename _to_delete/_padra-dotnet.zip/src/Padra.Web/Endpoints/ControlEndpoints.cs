using System.IO.Compression;
using System.Net;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Padra.Core.Clients;
using Padra.Core.Configuration;
using Padra.Core.Discovery;
using Padra.Core.Networking;
using Padra.Core.Runtime;
using Padra.Web.Services;

namespace Padra.Web.Endpoints;

public sealed record AddModelRequest(string Repo, string? Quant, string? Alias,
    int? ContextLength, bool MakeDefault, string? Reasoning);

public sealed record NetworkRequest(string? Host, int? Port, bool? AllowLan, int? IdleTimeout);

public sealed record InstallRequest(List<string>? Targets, string? Scope);

public sealed record LaunchRequest(string Agent, string? Alias, string Folder);

/// <summary>Everything the control panel calls, and everything a script can automate.</summary>
public static class ControlEndpoints
{
    public static IEndpointRouteBuilder MapControlEndpoints(this IEndpointRouteBuilder app)
    {
        var api = app.MapGroup("/api");

        // ---------------------------------------------------------- status #
        api.MapGet("/status", (ModelFleet fleet) => Results.Json(new
        {
            mode = fleet.Gateway.Mode.ToString().ToLowerInvariant(),
            defaultModel = fleet.DefaultAlias,
            backends = fleet.Backends.Select(b => b.Status()).ToList(),
            models = FleetPayload(fleet),
            network = NetworkPayload(fleet),
        }));

        api.MapGet("/log", (ActivityLog log, long since) =>
        {
            var entries = log.Since(since);
            return Results.Json(new
            {
                entries = entries.Select(e => new
                {
                    seq = e.Seq,
                    at = e.At.ToUnixTimeMilliseconds(),
                    text = e.Text,
                }).ToList(),
                cursor = entries.Count > 0 ? entries[^1].Seq : since,
            });
        });

        api.MapGet("/diagnostics", (ModelFleet fleet) => Results.Json(new
        {
            runtime = Environment.Version.ToString(),
            platform = Environment.OSVersion.ToString(),
            configPath = fleet.ConfigPath,
            gatewayHost = fleet.Gateway.Host,
            gatewayPort = fleet.Gateway.Port,
            hasApiKey = fleet.ApiKey.Length > 0,
            unslothPath = ExecutableFinder.Find(fleet.Gateway.UnslothBin) ?? string.Empty,
            cacheRoots = ModelScanner.HuggingFaceCacheRoots()
                .Select(r => new { path = r, exists = Directory.Exists(r) }).ToList(),
            backendPorts = fleet.Options.Models.Select(m => new
            {
                alias = m.Alias,
                port = m.Port,
                free = NetworkInfo.PortIsFree("127.0.0.1", m.Port),
            }).ToList(),
        }));

        // ----------------------------------------------------------- fleet #
        api.MapPost("/models/{alias}/load", async (string alias, ModelFleet fleet,
            CancellationToken token) => await LoadAsync(alias, fleet, token).ConfigureAwait(false));

        api.MapPost("/models/{alias}/unload", async (string alias, ModelFleet fleet,
            CancellationToken token) =>
        {
            var backend = fleet.Find(alias);
            if (backend is null)
            {
                return NotFound(alias);
            }

            await fleet.UnloadAsync(backend, token).ConfigureAwait(false);
            return Results.Json(backend.Status());
        });

        api.MapPost("/models/{alias}/activate", async (string alias, ModelFleet fleet,
            UserSettings settings, ActivityLog log, CancellationToken token) =>
        {
            var backend = fleet.Find(alias);
            if (backend is null)
            {
                return NotFound(alias);
            }

            fleet.SetDefault(backend.Alias);
            settings.Update(s => s.SelectedAlias = backend.Alias);

            if (fleet.Gateway.Mode == FleetMode.Exclusive)
            {
                foreach (var other in fleet.Backends.Where(b => b != backend && b.IsRunning).ToList())
                {
                    await fleet.UnloadAsync(other, token).ConfigureAwait(false);
                }
            }

            try
            {
                await fleet.EnsureAsync(backend, token).ConfigureAwait(false);
            }
            catch (BackendStartException ex)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.ServiceUnavailable, ex.Message,
                    "backend_start_error");
            }

            log.Write($"{backend.Alias} is now the active model");
            return Results.Json(backend.Status());
        });

        api.MapPost("/models", (AddModelRequest request, ModelFleet fleet,
            ModelLibrary library, ActivityLog log) =>
        {
            var draft = fleet.Options.Clone();
            ModelOptions entry;
            try
            {
                entry = FleetFile.AddModel(draft, request.Repo, request.Quant ?? string.Empty,
                    request.Alias ?? string.Empty, request.ContextLength,
                    reasoning: request.Reasoning ?? string.Empty,
                    makeDefault: request.MakeDefault);
            }
            catch (FleetFileException ex)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest, ex.Message,
                    "invalid_request_error");
            }

            if (!TryApply(fleet, draft, log, out var failure))
            {
                return failure!;
            }

            library.Invalidate();
            log.Write($"added `{entry.Alias}` -> {entry.ModelSpec}");
            return Results.Json(new
            {
                ok = true,
                model = new { alias = entry.Alias, repo = entry.Repo, quant = entry.Quant },
                models = FleetPayload(fleet),
            });
        });

        api.MapDelete("/models/{alias}", async (string alias, ModelFleet fleet,
            ModelLibrary library, ActivityLog log, CancellationToken token) =>
        {
            var backend = fleet.Find(alias);
            if (backend is null)
            {
                return NotFound(alias);
            }

            if (backend.IsRunning)
            {
                await fleet.UnloadAsync(backend, token).ConfigureAwait(false);
            }

            var draft = fleet.Options.Clone();
            try
            {
                FleetFile.RemoveModel(draft, alias);
            }
            catch (FleetFileException ex)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest, ex.Message,
                    "invalid_request_error");
            }

            if (!TryApply(fleet, draft, log, out var failure))
            {
                return failure!;
            }

            library.Invalidate();
            log.Write($"removed `{alias}` from the fleet");
            return Results.Json(new { ok = true, models = FleetPayload(fleet) });
        });

        // ------------------------------------------------------- discovery #
        api.MapGet("/models/local", async (ModelLibrary library, bool refresh,
            CancellationToken token) =>
        {
            var snapshot = await library.LocalAsync(refresh, token).ConfigureAwait(false);
            return Results.Json(new
            {
                models = snapshot.Models.Select(LocalPayload).ToList(),
                roots = snapshot.Roots,
                totalBytes = snapshot.TotalBytes,
                scannedAt = snapshot.ScannedAt.ToUnixTimeMilliseconds(),
            });
        });

        api.MapGet("/models/catalog", async (ModelLibrary library, string? search, string? repo,
            bool refresh, CancellationToken token) =>
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(repo))
                {
                    var record = await library.Catalog.VariantsAsync(repo!, refresh, token)
                        .ConfigureAwait(false);
                    var local = await library.LocalModelsAsync(token).ConfigureAwait(false);
                    return Results.Json(new { repo = HuggingFaceCatalog.MergeDownloaded(record, local) });
                }

                var repos = await library.Catalog
                    .RepositoriesAsync(search ?? string.Empty, refresh: refresh, token: token)
                    .ConfigureAwait(false);
                var downloaded = (await library.LocalModelsAsync(token).ConfigureAwait(false))
                    .Select(m => m.Repo.ToLowerInvariant()).ToHashSet();

                return Results.Json(new
                {
                    repos = repos.Select(r => new
                    {
                        repo = r.Repo,
                        downloads = r.Downloads,
                        likes = r.Likes,
                        lastModified = r.LastModified,
                        hasLocal = downloaded.Contains(r.Repo.ToLowerInvariant()),
                    }).ToList(),
                });
            }
            catch (CatalogException ex)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.ServiceUnavailable, ex.Message,
                    "catalog_error");
            }
        });

        // --------------------------------------------------------- network #
        api.MapGet("/network", (ModelFleet fleet) => Results.Json(NetworkPayload(fleet)));

        api.MapPost("/network", (NetworkRequest request, ModelFleet fleet, ActivityLog log) =>
        {
            var draft = fleet.Options.Clone();
            var restart = false;

            if (request.AllowLan is { } allow)
            {
                draft.Gateway.AllowLan = allow;
                draft.Gateway.Host = allow ? "0.0.0.0" : "127.0.0.1";
                restart = true;
            }

            if (!string.IsNullOrWhiteSpace(request.Host))
            {
                draft.Gateway.Host = request.Host!.Trim();
                draft.Gateway.AllowLan = draft.Gateway.IsShared;
                restart = true;
            }

            if (request.Port is { } port)
            {
                draft.Gateway.Port = port;
                restart = true;
            }

            if (request.IdleTimeout is { } idle)
            {
                draft.Gateway.IdleTimeout = idle;
            }

            if (restart && draft.Gateway.AllowLan && fleet.ApiKey.Length == 0)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest,
                    "Set a gateway API key before sharing on the network.", "invalid_request_error");
            }

            if (!TryApply(fleet, draft, log, out var failure))
            {
                return failure!;
            }

            return Results.Json(new
            {
                ok = true,
                restartRequired = restart,
                network = NetworkPayload(fleet),
            });
        });

        api.MapPost("/network/firewall", async (ModelFleet fleet, ActivityLog log,
            CancellationToken token) =>
        {
            var port = fleet.Gateway.Port;
            var result = await FirewallHelper.OpenAsync(port, token).ConfigureAwait(false);
            log.Write($"firewall rule for port {port}: " +
                      (result.Ok ? "added" : $"not added — run: {result.Command}"));
            return Results.Json(new
            {
                ok = result.Ok,
                elevated = result.Elevated,
                command = result.Command,
                output = result.Output,
            });
        });

        // --------------------------------------------------------- clients #
        api.MapGet("/clients", (ModelFleet fleet) =>
        {
            var unsloth = ExecutableFinder.Find(fleet.Gateway.UnslothBin);
            return Results.Json(new
            {
                unsloth = new { installed = unsloth is not null, path = unsloth ?? string.Empty },
                agents = AgentLauncher.AllAvailability().Select(a => new
                {
                    id = AgentLauncher.Slug(a.Agent),
                    installed = a.Installed,
                    path = a.Path,
                }).OrderBy(a => a.id, StringComparer.Ordinal).ToList(),
                vscodeFolders = ClientConfigWriter.VsCodeUserDirectories(),
                targets = ClientConfigWriter.AllTargets.Select(ClientConfigWriter.Slug).ToList(),
            });
        });

        api.MapGet("/client-configs", (ModelFleet fleet, string? scope) =>
        {
            var context = Context(fleet, scope);
            if (context.Models.Count == 0)
            {
                return NoModels();
            }

            return Results.Json(new
            {
                baseUrl = context.BaseUrl,
                files = ClientConfigWriter.GeneratedFiles(context),
            });
        });

        api.MapGet("/client-bundle", (ModelFleet fleet, ActivityLog log, string? scope) =>
        {
            var context = Context(fleet, scope ?? "lan");
            if (context.Models.Count == 0)
            {
                return NoModels();
            }

            using var buffer = new MemoryStream();
            using (var archive = new ZipArchive(buffer, ZipArchiveMode.Create, leaveOpen: true))
            {
                foreach (var (relative, content) in ClientConfigWriter.GeneratedFiles(context))
                {
                    var entry = archive.CreateEntry($"padra-client/{relative}");
                    using var stream = entry.Open();
                    var bytes = Encoding.UTF8.GetBytes(content);
                    stream.Write(bytes, 0, bytes.Length);
                }
            }

            log.Write($"client bundle generated for {context.BaseUrl}");
            return Results.File(buffer.ToArray(), "application/zip", "padra-client.zip");
        });

        api.MapPost("/install-configs", async (InstallRequest request, ModelFleet fleet,
            UserSettings settings, ActivityLog log) =>
        {
            if (!TryTargets(request.Targets, out var targets, out var unknown))
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest,
                    $"Unknown target(s): {string.Join(", ", unknown)}", "invalid_request_error");
            }

            var context = Context(fleet, request.Scope);
            if (context.Models.Count == 0)
            {
                return NoModels();
            }

            var output = Path.Combine(Path.GetDirectoryName(fleet.ConfigPath) ?? ".", "generated");
            var report = await Task.Run(() =>
            {
                ClientConfigWriter.WriteGenerated(context, output, targets);
                return ClientConfigWriter.Install(context, targets);
            }).ConfigureAwait(false);

            foreach (var line in report.Lines)
            {
                log.Write(line);
            }

            settings.Update(s => s.InstallTargets = targets.Select(ClientConfigWriter.Slug).ToList());

            return Results.Json(new
            {
                ok = report.Ok,
                written = report.Written,
                failed = report.Failed,
                output = report.Lines,
                generated = output,
                baseUrl = context.BaseUrl,
            });
        });

        api.MapPost("/launch-agent", async (LaunchRequest request, ModelFleet fleet,
            UserSettings settings, ActivityLog log) =>
        {
            if (!AgentLauncher.TryParse(request.Agent, out var agent))
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest,
                    $"Unknown agent `{request.Agent}`", "invalid_request_error");
            }

            var alias = string.IsNullOrWhiteSpace(request.Alias) ? fleet.DefaultAlias : request.Alias!;
            var backend = fleet.Find(alias);
            if (backend is null)
            {
                return NotFound(alias);
            }

            var folder = Environment.ExpandEnvironmentVariables(request.Folder ?? string.Empty);
            if (!Directory.Exists(folder))
            {
                return GatewayEndpoints.Problem(HttpStatusCode.BadRequest, "folder",
                    "invalid_request_error", new { path = folder });
            }

            var availability = AgentLauncher.Availability(agent);
            if (!availability.Installed)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.FailedDependency, "missing",
                    "missing_agent", new { agent = AgentLauncher.Slug(agent) });
            }

            var context = Context(fleet, "local");

            // Codex resolves `--profile <alias>` from ~/.codex/<alias>.config.toml, so the
            // agent's own configuration has to exist before the terminal opens. The
            // installers are idempotent, so this is safe to repeat.
            var report = await Task.Run(() => ClientConfigWriter.Install(context, new[]
            {
                agent switch
                {
                    CodingAgent.Codex => ClientTarget.Codex,
                    CodingAgent.Qwen => ClientTarget.Qwen,
                    _ => ClientTarget.Claude,
                },
            })).ConfigureAwait(false);

            foreach (var line in report.Lines)
            {
                log.Write(line);
            }

            if (!report.Ok)
            {
                return GatewayEndpoints.Problem(HttpStatusCode.InternalServerError,
                    $"Could not write the {AgentLauncher.Slug(agent)} configuration.", "install_error");
            }

            settings.Update(s =>
            {
                s.ProjectFolder = folder;
                s.SelectedAlias = backend.Alias;
                s.LastAgent = AgentLauncher.Slug(agent);
            });

            var result = await Task.Run(() => AgentLauncher.Launch(
                agent, backend.Alias, folder,
                AgentLauncher.Environment(agent, context, backend.Alias),
                AgentLauncher.CommandLine(agent, backend.Alias), log)).ConfigureAwait(false);

            if (!result.Started)
            {
                return Results.Json(new { ok = false, command = result.ScriptPath });
            }

            log.Write($"launched {AgentLauncher.Slug(agent)} with {backend.Alias} in {folder}");
            return Results.Json(new
            {
                ok = true,
                agent = AgentLauncher.Slug(agent),
                alias = backend.Alias,
                folder,
            });
        });

        api.MapPost("/shutdown", (ShutdownSignal shutdown) =>
        {
            shutdown.Request();
            return Results.Json(new { ok = true });
        });

        return app;
    }

    // ------------------------------------------------------------- helpers #
    public static ClientContext Context(ModelFleet fleet, string? scope)
    {
        var baseUrl = string.Equals(scope, "lan", StringComparison.OrdinalIgnoreCase)
            ? NetworkInfo.PreferredLanUrl(fleet.Gateway.Host, fleet.Gateway.Port)
            : ClientContext.DefaultBaseUrl(fleet.Options);

        return ClientContext.FromFleet(fleet.Options, baseUrl,
            Path.GetDirectoryName(fleet.ConfigPath));
    }

    public static bool TryTargets(List<string>? requested, out List<ClientTarget> targets,
        out List<string> unknown)
    {
        targets = new List<ClientTarget>();
        unknown = new List<string>();

        if (requested is null || requested.Count == 0)
        {
            targets = ClientConfigWriter.AllTargets.ToList();
            return true;
        }

        foreach (var value in requested)
        {
            if (ClientConfigWriter.TryParseTarget(value, out var parsed))
            {
                targets.Add(parsed);
            }
            else
            {
                unknown.Add(value);
            }
        }

        return unknown.Count == 0;
    }

    public static object NetworkPayload(ModelFleet fleet)
    {
        var map = NetworkInfo.EndpointUrls(fleet.Gateway.Host, fleet.Gateway.Port);
        return new
        {
            shared = map.Shared,
            host = map.Host,
            port = map.Port,
            localUrl = map.LocalUrl,
            lan = map.Lan.Select(e => new
            {
                address = e.Address,
                family = e.Family,
                url = e.Url,
                primary = e.Primary,
            }).ToList(),
            allowLan = fleet.Gateway.AllowLan,
            hostname = NetworkInfo.HostName,
            firewallCommand = FirewallHelper.Command(fleet.Gateway.Port),
            canOpenFirewall = FirewallHelper.IsWindows,
            idleTimeout = fleet.Gateway.IdleTimeout,
        };
    }

    public static List<object> FleetPayload(ModelFleet fleet) =>
        fleet.Options.Models.Select(m => (object)new
        {
            alias = m.Alias,
            repo = m.Repo,
            quant = m.Quant,
            port = m.Port,
            contextLength = m.ContextLength,
            isDefault = m.Alias == fleet.DefaultAlias,
        }).ToList();

    private static object LocalPayload(LibraryEntry entry) => new
    {
        repo = entry.Model.Repo,
        quant = entry.Model.Quant,
        spec = entry.Model.Spec,
        source = entry.Model.Source.ToString().ToLowerInvariant(),
        sizeBytes = entry.Model.SizeBytes,
        fileCount = entry.Model.FileCount,
        modified = entry.Model.Modified.ToUnixTimeMilliseconds(),
        path = entry.Model.Path,
        contextLength = entry.Model.ContextLength,
        architecture = entry.Model.Architecture,
        downloaded = true,
        inFleet = entry.InFleet,
    };

    private static async Task<IResult> LoadAsync(string alias, ModelFleet fleet, CancellationToken token)
    {
        var backend = fleet.Find(alias);
        if (backend is null)
        {
            return NotFound(alias);
        }

        try
        {
            await fleet.EnsureAsync(backend, token).ConfigureAwait(false);
        }
        catch (BackendStartException ex)
        {
            return GatewayEndpoints.Problem(HttpStatusCode.ServiceUnavailable, ex.Message,
                "backend_start_error");
        }

        return Results.Json(backend.Status());
    }

    private static bool TryApply(ModelFleet fleet, FleetOptions draft, ActivityLog log,
        out IResult? failure)
    {
        try
        {
            var validated = FleetFile.Validate(draft);
            FleetFile.Save(fleet.ConfigPath, validated);
            foreach (var alias in fleet.Apply(validated))
            {
                log.Write($"{alias}: stopped because its configuration changed");
            }

            failure = null;
            return true;
        }
        catch (FleetFileException ex)
        {
            failure = GatewayEndpoints.Problem(HttpStatusCode.BadRequest, ex.Message,
                "invalid_request_error");
            return false;
        }
    }

    private static IResult NotFound(string alias) =>
        GatewayEndpoints.Problem(HttpStatusCode.NotFound, $"Unknown model `{alias}`",
            "invalid_request_error");

    private static IResult NoModels() =>
        GatewayEndpoints.Problem(HttpStatusCode.BadRequest,
            "Add a model before generating client configuration.", "invalid_request_error");
}
