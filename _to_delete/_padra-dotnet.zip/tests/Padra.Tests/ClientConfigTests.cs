using System.Text.Json;
using System.Text.Json.Nodes;
using Padra.Core.Clients;
using Padra.Core.Configuration;
using Xunit;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

namespace Padra.Tests;

[Collection("environment")]
public sealed class ClientConfigTests
{
    private static ClientContext Context(string baseUrl = "http://127.0.0.1:8900/v1")
    {
        var options = FleetFile.Parse(string.Empty);
        options.Gateway.ApiKey = "sk-padra-test-key";
        FleetFile.AddModel(options, "unsloth/Qwen3.5-4B-GGUF", "UD-Q4_K_XL", contextLength: 262144);
        FleetFile.AddModel(options, "unsloth/gemma-4-26B-A4B-it-GGUF", "UD-Q4_K_XL",
            contextLength: 131072);
        return ClientContext.FromFleet(options, baseUrl);
    }

    private static JsonNode Read(string path) =>
        JsonNode.Parse(File.ReadAllText(path))!;

    // ================================================================= Codex #
    [Fact]
    public void The_codex_block_is_a_table_only()
    {
        var block = ClientConfigWriter.CodexProviderBlock(Context());

        Assert.StartsWith("[model_providers.unsloth_gw]", block, StringComparison.Ordinal);
        Assert.Contains("base_url             = \"http://127.0.0.1:8900/v1\"", block, StringComparison.Ordinal);
        Assert.Contains("env_key              = \"UNSLOTH_GATEWAY_KEY\"", block, StringComparison.Ordinal);
        Assert.Contains("wire_api             = \"responses\"", block, StringComparison.Ordinal);
        Assert.Contains("requires_openai_auth = false", block, StringComparison.Ordinal);
        Assert.DoesNotContain("oss_provider", block, StringComparison.Ordinal);

        // Nothing before the header: bare keys appended to an existing file would be
        // swallowed by whatever section came last.
        var firstMeaningfulLine = block.Split('\n').First(l => l.Trim().Length > 0);
        Assert.StartsWith("[", firstMeaningfulLine, StringComparison.Ordinal);
    }

    [Fact]
    public void The_managed_block_is_replaced_not_duplicated()
    {
        var first = ClientConfigWriter.ReplaceManagedBlock(string.Empty, "[model_providers.a]\nx = 1");
        var second = ClientConfigWriter.ReplaceManagedBlock(first, "[model_providers.a]\nx = 2");

        Assert.Equal(1, CountOccurrences(second, ClientConfigWriter.BlockBegin));
        Assert.Contains("x = 2", second, StringComparison.Ordinal);
        Assert.DoesNotContain("x = 1", second, StringComparison.Ordinal);
    }

    [Fact]
    public void An_existing_codex_file_keeps_its_own_content()
    {
        var existing = "model = \"gpt-5.6\"\n\n[tui]\nnotifications = true\n";
        var merged = ClientConfigWriter.ReplaceManagedBlock(
            existing, ClientConfigWriter.CodexProviderBlock(Context()));

        Assert.Contains("model = \"gpt-5.6\"", merged, StringComparison.Ordinal);
        Assert.Contains("[tui]", merged, StringComparison.Ordinal);
        Assert.Contains("[model_providers.unsloth_gw]", merged, StringComparison.Ordinal);
        // The user's root key still precedes the first table.
        Assert.True(merged.IndexOf("model = \"gpt-5.6\"", StringComparison.Ordinal) <
                    merged.IndexOf("[tui]", StringComparison.Ordinal));
    }

    [Fact]
    public void Codex_profiles_are_separate_files_with_top_level_keys()
    {
        using var environment = new TestEnvironment();
        var report = ClientConfigWriter.Install(Context(), new[] { ClientTarget.Codex });
        Assert.True(report.Ok);

        var profile = File.ReadAllText(environment.Path_(".codex", "qwen3.5-4b.config.toml"));
        Assert.Contains("model_provider       = \"unsloth_gw\"", profile, StringComparison.Ordinal);
        Assert.Contains("model                = \"qwen3.5-4b\"", profile, StringComparison.Ordinal);
        Assert.Contains("model_context_window = 262144", profile, StringComparison.Ordinal);
        Assert.DoesNotContain("[profiles", profile, StringComparison.Ordinal);

        Assert.Contains("[model_providers.unsloth_gw]",
            File.ReadAllText(environment.Path_(".codex", "config.toml")), StringComparison.Ordinal);
    }

    [Fact]
    public void Reinstalling_codex_is_idempotent_and_prunes_stale_profiles()
    {
        using var environment = new TestEnvironment();
        var context = Context();
        ClientConfigWriter.Install(context, new[] { ClientTarget.Codex });

        var stale = environment.Path_(".codex", "gone.config.toml");
        File.WriteAllText(stale, ClientConfigWriter.CodexProfile(
            new ClientModel("gone", "unsloth/Gone-GGUF", "Q4_K_M", 4096)));

        var report = ClientConfigWriter.Install(context, new[] { ClientTarget.Codex });

        Assert.True(report.Ok);
        Assert.False(File.Exists(stale));
        Assert.Equal(1, CountOccurrences(
            File.ReadAllText(environment.Path_(".codex", "config.toml")),
            ClientConfigWriter.BlockBegin));
        Assert.Contains(report.Lines, l => l.StartsWith("already current", StringComparison.Ordinal));
    }

    [Fact]
    public void An_existing_codex_config_is_backed_up()
    {
        using var environment = new TestEnvironment();
        var codex = environment.Path_(".codex");
        Directory.CreateDirectory(codex);
        File.WriteAllText(Path.Combine(codex, "config.toml"), "model = \"gpt-5.6\"\n");

        ClientConfigWriter.Install(Context(), new[] { ClientTarget.Codex });

        Assert.Equal("model = \"gpt-5.6\"\n",
            File.ReadAllText(Path.Combine(codex, "config.toml.bak")));
    }

    // ============================================================= Qwen Code #
    [Fact]
    public void Qwen_settings_merge_keeps_unrelated_keys()
    {
        using var environment = new TestEnvironment();
        var qwen = environment.Path_(".qwen");
        Directory.CreateDirectory(qwen);
        File.WriteAllText(Path.Combine(qwen, "settings.json"), """
            {
              "ui": { "theme": "dark" },
              "modelProviders": { "anthropic": [{ "id": "keep" }] },
              "security": { "auth": { "selectedType": "qwen-oauth" } }
            }
            """);

        ClientConfigWriter.Install(Context(), new[] { ClientTarget.Qwen });
        var data = Read(Path.Combine(qwen, "settings.json"));

        Assert.Equal("dark", data["ui"]!["theme"]!.GetValue<string>());
        Assert.Equal("keep", data["modelProviders"]!["anthropic"]![0]!["id"]!.GetValue<string>());
        Assert.Equal(new[] { "qwen3.5-4b", "gemma-4-26b-a4b-it" },
            data["modelProviders"]!["openai"]!.AsArray().Select(n => n!["id"]!.GetValue<string>()));
        Assert.Equal("openai", data["security"]!["auth"]!["selectedType"]!.GetValue<string>());
        Assert.Equal("qwen3.5-4b", data["model"]!["name"]!.GetValue<string>());
        Assert.Equal("http://127.0.0.1:8900/v1", data["env"]!["OPENAI_BASE_URL"]!.GetValue<string>());
        Assert.True(File.Exists(Path.Combine(qwen, "settings.json.bak")));
    }

    [Fact]
    public void Qwen_settings_survive_a_corrupt_file()
    {
        using var environment = new TestEnvironment();
        var qwen = environment.Path_(".qwen");
        Directory.CreateDirectory(qwen);
        File.WriteAllText(Path.Combine(qwen, "settings.json"), "{ this is not json");

        var report = ClientConfigWriter.Install(Context(), new[] { ClientTarget.Qwen });

        Assert.True(report.Ok);
        Assert.Equal("openai",
            Read(Path.Combine(qwen, "settings.json"))["security"]!["auth"]!["selectedType"]!
                .GetValue<string>());
    }

    // =========================================================== Claude Code #
    [Fact]
    public void Claude_settings_use_the_anthropic_surface()
    {
        using var environment = new TestEnvironment();
        ClientConfigWriter.Install(Context(), new[] { ClientTarget.Claude });

        var data = Read(environment.Path_(".claude", "settings.json"));
        var env = data["env"]!;

        Assert.Equal("http://127.0.0.1:8900", env["ANTHROPIC_BASE_URL"]!.GetValue<string>());
        Assert.Equal("sk-padra-test-key", env["ANTHROPIC_AUTH_TOKEN"]!.GetValue<string>());
        Assert.Equal("qwen3.5-4b", env["ANTHROPIC_MODEL"]!.GetValue<string>());
        Assert.Equal("qwen3.5-4b", env["ANTHROPIC_DEFAULT_SONNET_MODEL"]!.GetValue<string>());
        Assert.Equal("qwen3.5-4b", data["model"]!.GetValue<string>());
        Assert.Null(env["ANTHROPIC_API_KEY"]);
    }

    [Fact]
    public void Claude_settings_drop_a_conflicting_subscription_key()
    {
        using var environment = new TestEnvironment();
        var claude = environment.Path_(".claude");
        Directory.CreateDirectory(claude);
        File.WriteAllText(Path.Combine(claude, "settings.json"), """
            { "env": { "ANTHROPIC_API_KEY": "sk-ant-real", "MY_VAR": "keep" },
              "permissions": { "allow": ["Bash"] } }
            """);

        ClientConfigWriter.Install(Context(), new[] { ClientTarget.Claude });
        var data = Read(Path.Combine(claude, "settings.json"));

        Assert.Null(data["env"]!["ANTHROPIC_API_KEY"]);
        Assert.Equal("keep", data["env"]!["MY_VAR"]!.GetValue<string>());
        Assert.Equal("Bash", data["permissions"]!["allow"]![0]!.GetValue<string>());
    }

    // ================================================ Continue and VS Code #
    [Fact]
    public void The_continue_config_is_valid_yaml()
    {
        using var environment = new TestEnvironment();
        ClientConfigWriter.Install(Context(), new[] { ClientTarget.Continue });

        var yaml = new DeserializerBuilder()
            .WithNamingConvention(CamelCaseNamingConvention.Instance)
            .Build()
            .Deserialize<Dictionary<string, object>>(
                File.ReadAllText(environment.Path_(".continue", "config.yaml")));

        Assert.Equal("padra-unsloth", yaml["name"]);
        Assert.Equal("v1", yaml["schema"]);
        var models = Assert.IsType<List<object>>(yaml["models"]);
        var first = Assert.IsType<Dictionary<object, object>>(models[0]);
        Assert.Equal("openai", first["provider"]);
        Assert.Equal("http://127.0.0.1:8900/v1", first["apiBase"]);
    }

    [Fact]
    public void Vscode_settings_and_copilot_endpoints_are_written()
    {
        using var environment = new TestEnvironment();
        var userDirectory = environment.VsCodeUserDirectory();
        File.WriteAllText(Path.Combine(userDirectory, "settings.json"),
            "{\n  // a comment survives parsing\n  \"editor.fontSize\": 13,\n}\n");

        ClientConfigWriter.Install(Context(), new[] { ClientTarget.VsCode });

        var settings = Read(Path.Combine(userDirectory, "settings.json"));
        Assert.Equal(13, settings["editor.fontSize"]!.GetValue<int>());
        Assert.True(settings["claudeCode.disableLoginPrompt"]!.GetValue<bool>());
        Assert.Contains("ANTHROPIC_BASE_URL",
            settings["claudeCode.environmentVariables"]!.AsArray()
                .Select(n => n!["name"]!.GetValue<string>()));

        var models = Read(Path.Combine(userDirectory, "chatLanguageModels.json")).AsArray();
        Assert.Equal(new[] { "qwen3.5-4b", "gemma-4-26b-a4b-it" },
            models.Select(n => n!["id"]!.GetValue<string>()));
        Assert.Equal("customendpoint", models[0]!["vendor"]!.GetValue<string>());
        Assert.Equal("http://127.0.0.1:8900/v1/chat/completions",
            models[0]!["url"]!.GetValue<string>());
        Assert.Equal(262144, models[0]!["maxInputTokens"]!.GetValue<int>());
    }

    [Fact]
    public void Reinstalling_vscode_does_not_duplicate_endpoints()
    {
        using var environment = new TestEnvironment();
        var userDirectory = environment.VsCodeUserDirectory();
        File.WriteAllText(Path.Combine(userDirectory, "chatLanguageModels.json"),
            """[{ "vendor": "other", "id": "keep" }]""");

        ClientConfigWriter.Install(Context(), new[] { ClientTarget.VsCode });
        ClientConfigWriter.Install(Context(), new[] { ClientTarget.VsCode });

        var models = Read(Path.Combine(userDirectory, "chatLanguageModels.json")).AsArray();
        Assert.Equal(new[] { "keep", "qwen3.5-4b", "gemma-4-26b-a4b-it" },
            models.Select(n => n!["id"]!.GetValue<string>()));
    }

    [Fact]
    public void A_missing_vscode_folder_is_reported_not_fatal()
    {
        using var environment = new TestEnvironment();
        var report = ClientConfigWriter.Install(Context(), new[] { ClientTarget.VsCode });

        Assert.True(report.Ok);
        Assert.Contains(report.Lines, l => l.Contains("VS Code", StringComparison.Ordinal));
    }

    // ============================================================== bundle #
    [Fact]
    public void The_generated_bundle_covers_every_target()
    {
        using var environment = new TestEnvironment();
        var context = Context("http://192.168.1.20:8900/v1");
        var written = ClientConfigWriter.WriteGenerated(context, environment.Work);

        var names = written
            .Select(p => Path.GetRelativePath(environment.Work, p).Replace('\\', '/'))
            .ToHashSet(StringComparer.Ordinal);

        Assert.Superset(new HashSet<string>(StringComparer.Ordinal)
        {
            "codex/config.toml", "codex/qwen3.5-4b.config.toml", "qwen/settings.json",
            "claude/settings.json", "continue/config.yaml", "vscode/settings.json",
            "vscode/chatLanguageModels.json", "vscode/tasks.json",
            "env.sh", "env.ps1", "README.txt",
        }, names);

        var tasks = Read(Path.Combine(environment.Work, "vscode", "tasks.json"));
        Assert.Equal(new[] { "qwen3.5-4b", "gemma-4-26b-a4b-it" },
            tasks["inputs"]![0]!["options"]!.AsArray().Select(n => n!.GetValue<string>()));
        Assert.Contains("192.168.1.20",
            File.ReadAllText(Path.Combine(environment.Work, "env.sh")), StringComparison.Ordinal);
    }

    [Fact]
    public void The_lenient_json_reader_handles_comments_and_trailing_commas()
    {
        var node = ClientConfigWriter.ParseLenient("""
            {
              // line comment
              "a": 1, /* block */
              "b": "http://x/y // not a comment",
              "c": [1, 2,],
            }
            """);

        Assert.Equal(1, node!["a"]!.GetValue<int>());
        Assert.Equal("http://x/y // not a comment", node["b"]!.GetValue<string>());
        Assert.Equal(2, node["c"]!.AsArray().Count);
        Assert.Null(ClientConfigWriter.ParseLenient("   "));
    }

    [Fact]
    public void Target_names_round_trip()
    {
        Assert.True(ClientConfigWriter.TryParseTarget("vscode", out var vscode));
        Assert.Equal(ClientTarget.VsCode, vscode);
        Assert.True(ClientConfigWriter.TryParseTarget("Claude", out var claude));
        Assert.Equal(ClientTarget.Claude, claude);
        Assert.False(ClientConfigWriter.TryParseTarget("emacs", out _));
        Assert.Equal(new[] { "codex", "qwen", "claude", "continue", "vscode" },
            ClientConfigWriter.AllTargets.Select(ClientConfigWriter.Slug));
    }

    // ============================================================== launch #
    [Fact]
    public void Agent_command_lines_match_the_installed_configuration()
    {
        Assert.Equal(new[] { "codex", "--profile", "demo" },
            AgentLauncher.CommandLine(CodingAgent.Codex, "demo"));
        Assert.Equal(new[] { "qwen", "--model", "demo" },
            AgentLauncher.CommandLine(CodingAgent.Qwen, "demo"));
        Assert.Equal(new[] { "claude", "--model", "demo" },
            AgentLauncher.CommandLine(CodingAgent.Claude, "demo"));
    }

    [Fact]
    public void Agent_environments_target_the_right_api()
    {
        var context = Context();

        var claude = AgentLauncher.Environment(CodingAgent.Claude, context, "demo");
        Assert.Equal("http://127.0.0.1:8900", claude["ANTHROPIC_BASE_URL"]);
        Assert.Equal("demo", claude["ANTHROPIC_MODEL"]);
        Assert.Equal("sk-padra-test-key", claude[ClientConfigWriter.EnvKeyName]);

        var qwen = AgentLauncher.Environment(CodingAgent.Qwen, context, "demo");
        Assert.Equal("http://127.0.0.1:8900/v1", qwen["OPENAI_BASE_URL"]);
        Assert.Equal("demo", qwen["OPENAI_MODEL"]);
    }

    [Fact]
    public void The_launch_script_quotes_folders_and_keys()
    {
        using var environment = new TestEnvironment();
        var folder = Path.Combine(environment.Work, "a folder with spaces");
        Directory.CreateDirectory(folder);

        var result = AgentLauncher.Launch(CodingAgent.Codex, "demo", folder,
            new Dictionary<string, string> { ["KEY"] = "va\"lue with spaces" },
            AgentLauncher.CommandLine(CodingAgent.Codex, "demo"),
            new Padra.Core.Runtime.ActivityLog());

        var script = File.ReadAllText(result.ScriptPath);
        Assert.Contains("a folder with spaces", script, StringComparison.Ordinal);
        Assert.Contains("codex", script, StringComparison.Ordinal);
        Assert.Contains("va\"lue with spaces", script, StringComparison.Ordinal);
        File.Delete(result.ScriptPath);
    }

    private static int CountOccurrences(string text, string needle)
    {
        var count = 0;
        var index = text.IndexOf(needle, StringComparison.Ordinal);
        while (index >= 0)
        {
            count++;
            index = text.IndexOf(needle, index + needle.Length, StringComparison.Ordinal);
        }

        return count;
    }
}
