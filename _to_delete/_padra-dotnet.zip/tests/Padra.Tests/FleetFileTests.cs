using Padra.Core.Configuration;
using Xunit;

namespace Padra.Tests;

public sealed class FleetFileTests
{
    [Fact]
    public void Defaults_are_applied_to_an_empty_file()
    {
        var options = FleetFile.Parse(string.Empty);

        Assert.Equal("127.0.0.1", options.Gateway.Host);
        Assert.Equal(8900, options.Gateway.Port);
        Assert.Equal(FleetMode.Exclusive, options.Gateway.Mode);
        Assert.Equal(CodexWireApi.Responses, options.Gateway.WireApi);
        Assert.Equal(UnknownModelBehaviour.Default, options.Gateway.UnknownModel);
        Assert.Empty(options.Gateway.DefaultModel);
        Assert.Empty(options.Models);
    }

    [Fact]
    public void Model_entries_are_normalised()
    {
        var options = FleetFile.Parse("""
            models:
              - alias: Demo
                repo: unsloth/X-GGUF
                quant: UD-Q4_K_XL
                port: 8801
                contextLength: 4096
                extraArgs: ["--temp", "0.6"]
            """);

        var model = Assert.Single(options.Models);
        Assert.Equal("demo", model.Alias);
        Assert.Equal(8801, model.Port);
        Assert.Equal(4096, model.ContextLength);
        Assert.Equal(new[] { "--temp", "0.6" }, model.ExtraArgs);
        Assert.True(model.DisableTools);
        Assert.Equal("demo", options.Gateway.DefaultModel);
        Assert.Equal("unsloth/X-GGUF:UD-Q4_K_XL", model.ModelSpec);
    }

    [Theory]
    [InlineData("models:\n  - repo: x\n", "alias")]
    [InlineData("models:\n  - alias: a\n    repo: x\n    port: 70000\n", "between")]
    [InlineData("models:\n  - alias: A B\n    repo: x\n", "lowercase")]
    [InlineData("gateway:\n  mode: turbo\n", "mode")]
    [InlineData("gateway:\n  wireApi: grpc\n", "wireApi")]
    [InlineData("gateway:\n  unknownModel: maybe\n", "unknownModel")]
    [InlineData("gateway:\n  defaultModel: ghost\n", "defaultModel")]
    public void Invalid_configurations_are_rejected(string yaml, string expected)
    {
        var error = Assert.Throws<FleetFileException>(() => FleetFile.Parse(yaml));
        Assert.Contains(expected, error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void Duplicate_alias_and_port_are_rejected()
    {
        Assert.Contains("duplicate alias", Assert.Throws<FleetFileException>(() =>
            FleetFile.Parse("""
                models:
                  - {alias: a, repo: x, port: 8801}
                  - {alias: a, repo: y, port: 8802}
                """)).Message);

        Assert.Contains("port 8801", Assert.Throws<FleetFileException>(() =>
            FleetFile.Parse("""
                models:
                  - {alias: a, repo: x, port: 8801}
                  - {alias: b, repo: y, port: 8801}
                """)).Message);
    }

    [Fact]
    public void A_model_cannot_take_the_gateway_port()
    {
        var error = Assert.Throws<FleetFileException>(() => FleetFile.Parse("""
            gateway:
              port: 8900
            models:
              - {alias: a, repo: x, port: 8900}
            """));
        Assert.Contains("gateway port", error.Message);
    }

    [Fact]
    public void The_placeholder_api_key_is_replaced_once()
    {
        var options = FleetFile.Parse("gateway:\n  apiKey: sk-gateway-local-change-me\n");

        Assert.True(FleetFile.EnsureApiKey(options));
        Assert.StartsWith("sk-padra-", options.Gateway.ApiKey, StringComparison.Ordinal);
        Assert.True(options.Gateway.ApiKey.Length > 30);
        Assert.False(FleetFile.EnsureApiKey(options));
    }

    [Fact]
    public void Models_can_be_added_removed_and_defaulted()
    {
        var options = FleetFile.Parse(string.Empty);

        var first = FleetFile.AddModel(options, "unsloth/Qwen3.5-4B-GGUF", "UD-Q4_K_XL",
            contextLength: 262144);
        Assert.Equal("qwen3.5-4b", first.Alias);
        Assert.Equal(FleetOptions.FirstBackendPort, first.Port);
        Assert.Equal("qwen3.5-4b", options.Gateway.DefaultModel);

        var second = FleetFile.AddModel(options, "unsloth/Qwen3.5-4B-GGUF", "Q8_0");
        Assert.Equal("qwen3.5-4b-q8_0", second.Alias);
        Assert.Equal(FleetOptions.FirstBackendPort + 1, second.Port);

        Assert.Contains("already in the fleet", Assert.Throws<FleetFileException>(() =>
            FleetFile.AddModel(options, "unsloth/Qwen3.5-4B-GGUF", "Q8_0")).Message);

        FleetFile.SetDefaultModel(options, "qwen3.5-4b-q8_0");
        Assert.Equal("qwen3.5-4b-q8_0", options.Gateway.DefaultModel);

        FleetFile.RemoveModel(options, "qwen3.5-4b-q8_0");
        Assert.Equal(new[] { "qwen3.5-4b" }, options.Models.Select(m => m.Alias));
        Assert.Equal("qwen3.5-4b", options.Gateway.DefaultModel);

        FleetFile.RemoveModel(options, "qwen3.5-4b");
        Assert.Empty(options.Gateway.DefaultModel);
        Assert.Throws<FleetFileException>(() => FleetFile.RemoveModel(options, "qwen3.5-4b"));
    }

    [Fact]
    public void Saving_is_atomic_and_round_trips()
    {
        using var environment = new TestEnvironment();
        var options = FleetFile.Parse(string.Empty);
        FleetFile.AddModel(options, "unsloth/gemma-4-26B-A4B-it-GGUF", "UD-Q4_K_XL",
            contextLength: 131072);
        options.Gateway.ApiKey = "sk-padra-round-trip";

        FleetFile.Save(environment.ConfigPath, options);

        var text = File.ReadAllText(environment.ConfigPath);
        Assert.StartsWith("# Padra Platform Launcher", text, StringComparison.Ordinal);
        Assert.Empty(Directory.GetFiles(environment.Work, "*.tmp"));

        var reloaded = FleetFile.Load(environment.ConfigPath);
        Assert.Equal("gemma-4-26b-a4b-it", reloaded.Models[0].Alias);
        Assert.Equal("unsloth/gemma-4-26B-A4B-it-GGUF", reloaded.Models[0].Repo);
        Assert.Equal(131072, reloaded.Models[0].ContextLength);
        Assert.Equal("sk-padra-round-trip", reloaded.Gateway.ApiKey);
        Assert.Equal(options.Gateway.DefaultModel, reloaded.Gateway.DefaultModel);
    }

    [Fact]
    public void Loading_reports_a_missing_file()
    {
        using var environment = new TestEnvironment();
        var error = Assert.Throws<FleetFileException>(() =>
            FleetFile.Load(Path.Combine(environment.Work, "nope.yaml")));
        Assert.Contains("config not found", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void Invalid_yaml_is_reported_not_thrown_raw()
    {
        var error = Assert.Throws<FleetFileException>(() => FleetFile.Parse("gateway: [1, 2\n"));
        Assert.Contains("not valid YAML", error.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void The_next_free_port_skips_everything_in_use()
    {
        var options = FleetFile.Parse("""
            gateway:
              port: 8802
            models:
              - {alias: a, repo: x, port: 8801}
            """);
        Assert.Equal(8803, FleetFile.NextFreePort(options));
    }

    [Fact]
    public void Validate_keeps_the_chosen_default_and_key()
    {
        var options = FleetFile.Parse(string.Empty);
        options.Gateway.ApiKey = "sk-padra-keep";
        FleetFile.AddModel(options, "unsloth/A-GGUF", "Q4_K_M");
        FleetFile.AddModel(options, "unsloth/B-GGUF", "Q4_K_M");
        FleetFile.SetDefaultModel(options, "b");

        var validated = FleetFile.Validate(options);
        Assert.Equal("b", validated.Gateway.DefaultModel);
        Assert.Equal("sk-padra-keep", validated.Gateway.ApiKey);
        Assert.Equal(2, validated.Models.Count);
    }

    [Fact]
    public void The_starter_config_is_valid()
    {
        var options = FleetFile.Parse(StarterConfig.Yaml);
        Assert.Empty(options.Models);
        Assert.True(options.Gateway.AutoImport);
        Assert.Equal(8900, options.Gateway.Port);
    }
}
